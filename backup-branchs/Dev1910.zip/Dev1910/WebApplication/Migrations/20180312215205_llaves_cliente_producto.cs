﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class llaves_cliente_producto : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Cliente_Productos_Clientes_Clienteid",
                table: "Cliente_Productos");

            migrationBuilder.DropForeignKey(
                name: "FK_Cliente_Productos_Cat_Estatus_Compra_EstatusCompraId",
                table: "Cliente_Productos");

            migrationBuilder.DropForeignKey(
                name: "FK_Cliente_Productos_Cat_Producto_Productoid",
                table: "Cliente_Productos");

            migrationBuilder.DropIndex(
                name: "IX_Cliente_Productos_Clienteid",
                table: "Cliente_Productos");

            migrationBuilder.DropIndex(
                name: "IX_Cliente_Productos_EstatusCompraId",
                table: "Cliente_Productos");

            migrationBuilder.DropIndex(
                name: "IX_Cliente_Productos_Productoid",
                table: "Cliente_Productos");

            migrationBuilder.DropColumn(
                name: "Clienteid",
                table: "Cliente_Productos");

            migrationBuilder.DropColumn(
                name: "EstatusCompraId",
                table: "Cliente_Productos");

            migrationBuilder.DropColumn(
                name: "Productoid",
                table: "Cliente_Productos");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Id_Cliente",
                table: "Cliente_Productos",
                column: "Id_Cliente");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Id_EsatusCompra",
                table: "Cliente_Productos",
                column: "Id_EsatusCompra");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Id_Producto",
                table: "Cliente_Productos",
                column: "Id_Producto");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Cliente_Producto",
                table: "Cliente_Productos",
                column: "Id_Cliente",
                principalTable: "Clientes",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Cliente_Producto_Estatus",
                table: "Cliente_Productos",
                column: "Id_EsatusCompra",
                principalTable: "Cat_Estatus_Compra",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Cliente_Producto_Producto",
                table: "Cliente_Productos",
                column: "Id_Producto",
                principalTable: "Cat_Producto",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Cliente_Producto",
                table: "Cliente_Productos");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Cliente_Producto_Estatus",
                table: "Cliente_Productos");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Cliente_Producto_Producto",
                table: "Cliente_Productos");

            migrationBuilder.DropIndex(
                name: "IX_Cliente_Productos_Id_Cliente",
                table: "Cliente_Productos");

            migrationBuilder.DropIndex(
                name: "IX_Cliente_Productos_Id_EsatusCompra",
                table: "Cliente_Productos");

            migrationBuilder.DropIndex(
                name: "IX_Cliente_Productos_Id_Producto",
                table: "Cliente_Productos");

            migrationBuilder.AddColumn<long>(
                name: "Clienteid",
                table: "Cliente_Productos",
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "EstatusCompraId",
                table: "Cliente_Productos",
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "Productoid",
                table: "Cliente_Productos",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Clienteid",
                table: "Cliente_Productos",
                column: "Clienteid");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_EstatusCompraId",
                table: "Cliente_Productos",
                column: "EstatusCompraId");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Productoid",
                table: "Cliente_Productos",
                column: "Productoid");

            migrationBuilder.AddForeignKey(
                name: "FK_Cliente_Productos_Clientes_Clienteid",
                table: "Cliente_Productos",
                column: "Clienteid",
                principalTable: "Clientes",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Cliente_Productos_Cat_Estatus_Compra_EstatusCompraId",
                table: "Cliente_Productos",
                column: "EstatusCompraId",
                principalTable: "Cat_Estatus_Compra",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Cliente_Productos_Cat_Producto_Productoid",
                table: "Cliente_Productos",
                column: "Productoid",
                principalTable: "Cat_Producto",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
