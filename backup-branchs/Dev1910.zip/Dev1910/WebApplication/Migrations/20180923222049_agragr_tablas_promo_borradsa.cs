﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class agragr_tablas_promo_borradsa : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "entidades_obligatorias",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_entidad = table.Column<int>(type: "int", nullable: false),
                    id_promocion = table.Column<int>(type: "int", nullable: false),
                    id_tipo_entidad = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_entidades_obligatorias", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_4entidadesobli_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_entidades_obligatorias_cattipoentidades2",
                        column: x => x.id_tipo_entidad,
                        principalTable: "cat_tipo_entidades",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "productos_excluidos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_producto = table.Column<int>(type: "int", nullable: false),
                    id_promocion = table.Column<int>(type: "int", nullable: false),
                    id_tipo_categoria = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_productos_excluidos", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_5productos_excluidos_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "promociones_compatibles",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_promocion = table.Column<int>(type: "int", nullable: false),
                    id_promocion_2 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_promociones_compatibles", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_5promocompatibles1_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_entidades_obligatorias_id_promocion",
                table: "entidades_obligatorias",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_entidades_obligatorias_id_tipo_entidad",
                table: "entidades_obligatorias",
                column: "id_tipo_entidad");

            migrationBuilder.CreateIndex(
                name: "IX_productos_excluidos_id_promocion",
                table: "productos_excluidos",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_promociones_compatibles_id_promocion",
                table: "promociones_compatibles",
                column: "id_promocion");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "entidades_obligatorias");

            migrationBuilder.DropTable(
                name: "productos_excluidos");

            migrationBuilder.DropTable(
                name: "promociones_compatibles");
        }
    }
}
