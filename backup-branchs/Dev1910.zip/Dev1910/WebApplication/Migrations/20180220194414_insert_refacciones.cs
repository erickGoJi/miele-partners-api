﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class insert_refacciones : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_Lista_Precios",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    grupo_precio = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    precio_sin_iva = table.Column<decimal>(type: "decimal(18, 2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Lista_Precios", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Materiales",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_grupo_precio = table.Column<int>(type: "int", nullable: false),
                    no_material = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Materiales", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Material_Grupo_Precio",
                        column: x => x.id_grupo_precio,
                        principalTable: "Cat_Lista_Precios",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Materiales_id_grupo_precio",
                table: "Cat_Materiales",
                column: "id_grupo_precio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cat_Materiales");

            migrationBuilder.DropTable(
                name: "Cat_Lista_Precios");
        }
    }
}
