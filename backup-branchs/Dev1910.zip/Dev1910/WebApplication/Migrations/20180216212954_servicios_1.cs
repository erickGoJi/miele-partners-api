﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "categoria_servicio",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "direccion",
                table: "Servicio");

            migrationBuilder.AddColumn<int>(
                name: "cat_direccionid",
                table: "Servicio",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "categoria_servicioid",
                table: "Servicio",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_categoria_servicio",
                table: "Servicio",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "id_direccion",
                table: "Servicio",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Cat_Categoria_Servicio",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_categoria_servicio = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Categoria_Servicio", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Direccion",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    calle_numero = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    colonia = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estadoid = table.Column<int>(type: "int", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_estado = table.Column<int>(type: "int", nullable: false),
                    id_municipio = table.Column<int>(type: "int", nullable: false),
                    municipioid = table.Column<int>(type: "int", nullable: true),
                    telefono = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Direccion", x => x.id);
                    table.ForeignKey(
                        name: "FK_Cat_Direccion_Cat_Estado_estadoid",
                        column: x => x.estadoid,
                        principalTable: "Cat_Estado",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Cat_Direccion_Cat_Municipio_municipioid",
                        column: x => x.municipioid,
                        principalTable: "Cat_Municipio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_cat_direccionid",
                table: "Servicio",
                column: "cat_direccionid");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_categoria_servicioid",
                table: "Servicio",
                column: "categoria_servicioid");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Direccion_estadoid",
                table: "Cat_Direccion",
                column: "estadoid");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Direccion_municipioid",
                table: "Cat_Direccion",
                column: "municipioid");

            migrationBuilder.AddForeignKey(
                name: "FK_Servicio_Cat_Direccion_cat_direccionid",
                table: "Servicio",
                column: "cat_direccionid",
                principalTable: "Cat_Direccion",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Servicio_Cat_Categoria_Servicio_categoria_servicioid",
                table: "Servicio",
                column: "categoria_servicioid",
                principalTable: "Cat_Categoria_Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Servicio_Cat_Direccion_cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropForeignKey(
                name: "FK_Servicio_Cat_Categoria_Servicio_categoria_servicioid",
                table: "Servicio");

            migrationBuilder.DropTable(
                name: "Cat_Categoria_Servicio");

            migrationBuilder.DropTable(
                name: "Cat_Direccion");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_categoria_servicioid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "categoria_servicioid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "id_categoria_servicio",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "id_direccion",
                table: "Servicio");

            migrationBuilder.AddColumn<int>(
                name: "categoria_servicio",
                table: "Servicio",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "direccion",
                table: "Servicio",
                nullable: false,
                defaultValue: 0);
        }
    }
}
