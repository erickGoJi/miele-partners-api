﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarFormasDepago : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "nivel",
                table: "Cat_Roles");

            migrationBuilder.DropColumn(
                name: "CondicionPago",
                table: "Cat_CondicionesPago");

            migrationBuilder.AddColumn<int>(
                name: "id_Cat_Formas_Pago",
                table: "Cat_CondicionesPago",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_Cat_Formas_Pago",
                table: "Cat_CondicionesPago");

            migrationBuilder.AddColumn<int>(
                name: "nivel",
                table: "Cat_Roles",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "CondicionPago",
                table: "Cat_CondicionesPago",
                nullable: true);
        }
    }
}
