﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicio_subtipo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "id_sub_tipo_servicio",
                table: "Servicio",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "sub_tipo_servicioid",
                table: "Servicio",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_sub_tipo_servicioid",
                table: "Servicio",
                column: "sub_tipo_servicioid");

            migrationBuilder.AddForeignKey(
                name: "FK_Servicio_Sub_cat_tipo_servicio_sub_tipo_servicioid",
                table: "Servicio",
                column: "sub_tipo_servicioid",
                principalTable: "Sub_cat_tipo_servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Servicio_Sub_cat_tipo_servicio_sub_tipo_servicioid",
                table: "Servicio");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_sub_tipo_servicioid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "id_sub_tipo_servicio",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "sub_tipo_servicioid",
                table: "Servicio");
        }
    }
}
