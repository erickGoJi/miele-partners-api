﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class activar_credito_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Servicio_CierreCliente",
                table: "Servicio");

            migrationBuilder.DropTable(
                name: "Cat_Motivo_Cierre_Cliente");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_id_motivo_cierre",
                table: "Servicio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_Motivo_Cierre_Cliente",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_motivo_cierre = table.Column<string>(nullable: true),
                    estatus = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Motivo_Cierre_Cliente", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_motivo_cierre",
                table: "Servicio",
                column: "id_motivo_cierre");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Servicio_CierreCliente",
                table: "Servicio",
                column: "id_motivo_cierre",
                principalTable: "Cat_Motivo_Cierre_Cliente",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
