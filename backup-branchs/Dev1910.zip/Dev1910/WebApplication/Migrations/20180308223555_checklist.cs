﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class checklist : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Check_List_Categoria_Producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    categoria = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sku = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Check_List_Categoria_Producto", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Check_List_Preguntas",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_categoria = table.Column<int>(type: "int", nullable: false),
                    pregunta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pregunta_en = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Check_List_Preguntas", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Ckl_Categoria_Producto",
                        column: x => x.id_categoria,
                        principalTable: "Check_List_Categoria_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Check_List_Respuestas",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    comentarios = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    comentarios_en = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_pregunta = table.Column<int>(type: "int", nullable: false),
                    respuesta = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Check_List_Respuestas", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Ckl_Pregunta_Respuesta",
                        column: x => x.id_pregunta,
                        principalTable: "Check_List_Preguntas",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Check_List_Preguntas_id_categoria",
                table: "Check_List_Preguntas",
                column: "id_categoria");

            migrationBuilder.CreateIndex(
                name: "IX_Check_List_Respuestas_id_pregunta",
                table: "Check_List_Respuestas",
                column: "id_pregunta");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Check_List_Respuestas");

            migrationBuilder.DropTable(
                name: "Check_List_Preguntas");

            migrationBuilder.DropTable(
                name: "Check_List_Categoria_Producto");
        }
    }
}
