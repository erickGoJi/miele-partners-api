﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class borrar_tablas_promo_add_precios : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "cat_tipos_herencia");

            migrationBuilder.AddColumn<float>(
                name: "iva_precio_descuento",
                table: "Cotizacion_Producto",
                type: "real",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "iva_precio_lista",
                table: "Cotizacion_Producto",
                type: "real",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "precio_descuento",
                table: "Cotizacion_Producto",
                type: "real",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "precio_lista",
                table: "Cotizacion_Producto",
                type: "real",
                nullable: false,
                defaultValue: 0f);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "iva_precio_descuento",
                table: "Cotizacion_Producto");

            migrationBuilder.DropColumn(
                name: "iva_precio_lista",
                table: "Cotizacion_Producto");

            migrationBuilder.DropColumn(
                name: "precio_descuento",
                table: "Cotizacion_Producto");

            migrationBuilder.DropColumn(
                name: "precio_lista",
                table: "Cotizacion_Producto");

            migrationBuilder.CreateTable(
                name: "cat_tipos_herencia",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    tipo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cat_tipos_herencia", x => x.id);
                });
        }
    }
}
