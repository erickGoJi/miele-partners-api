﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class atributos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "atributus",
                table: "Cat_Productos");

            migrationBuilder.AddColumn<string>(
                name: "atributos",
                table: "Cat_Productos",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "atributos",
                table: "Cat_Productos");

            migrationBuilder.AddColumn<string>(
                name: "atributus",
                table: "Cat_Productos",
                nullable: true);
        }
    }
}
