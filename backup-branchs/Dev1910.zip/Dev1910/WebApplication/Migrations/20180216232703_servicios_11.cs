﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios_11 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Productos_Cat_Productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_Cat_Productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "Cat_Productosid",
                table: "Rel_servicio_Refaccion");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Cat_Productosid",
                table: "Rel_servicio_Refaccion",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_Cat_Productosid",
                table: "Rel_servicio_Refaccion",
                column: "Cat_Productosid");

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Productos_Cat_Productosid",
                table: "Rel_servicio_Refaccion",
                column: "Cat_Productosid",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
