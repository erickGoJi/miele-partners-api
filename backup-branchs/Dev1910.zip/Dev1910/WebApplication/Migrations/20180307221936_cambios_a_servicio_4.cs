﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class cambios_a_servicio_4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Servicio_Producto",
                table: "Rel_servicio_producto");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Servicio_Refaccion",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropTable(
                name: "Visita");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_id_vista",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_producto_id_vista",
                table: "Rel_servicio_producto");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Visita",
                columns: table => new
                {
                    id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actividades_realizar = table.Column<string>(nullable: true),
                    cantidad = table.Column<decimal>(nullable: false),
                    comprobante = table.Column<string>(nullable: true),
                    concepto = table.Column<string>(nullable: true),
                    factura = table.Column<bool>(nullable: false),
                    fecha_deposito = table.Column<string>(nullable: true),
                    fecha_visita = table.Column<DateTime>(nullable: false),
                    garantia = table.Column<bool>(nullable: false),
                    hora = table.Column<string>(nullable: true),
                    id_direccion = table.Column<int>(nullable: false),
                    id_servicio = table.Column<long>(nullable: false),
                    id_tecnico = table.Column<long>(nullable: false),
                    no_operacion = table.Column<string>(nullable: true),
                    pagado = table.Column<bool>(nullable: false),
                    pago_pendiente = table.Column<bool>(nullable: false),
                    terminos_condiciones = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Visita", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Visita",
                        column: x => x.id_servicio,
                        principalTable: "Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Tecnico_Visita",
                        column: x => x.id_tecnico,
                        principalTable: "Tecnicos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_vista",
                table: "Rel_servicio_Refaccion",
                column: "id_vista");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_id_vista",
                table: "Rel_servicio_producto",
                column: "id_vista");

            migrationBuilder.CreateIndex(
                name: "IX_Visita_id_servicio",
                table: "Visita",
                column: "id_servicio");

            migrationBuilder.CreateIndex(
                name: "IX_Visita_id_tecnico",
                table: "Visita",
                column: "id_tecnico");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Servicio_Producto",
                table: "Rel_servicio_producto",
                column: "id_vista",
                principalTable: "Visita",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Servicio_Refaccion",
                table: "Rel_servicio_Refaccion",
                column: "id_vista",
                principalTable: "Visita",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
