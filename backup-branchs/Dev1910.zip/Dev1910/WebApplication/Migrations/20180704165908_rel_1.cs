﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class rel_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Tecnicos_Actividad_Cat_tipo_servicio_actividadid",
                table: "Tecnicos_Actividad");

            migrationBuilder.DropIndex(
                name: "IX_Tecnicos_Actividad_actividadid",
                table: "Tecnicos_Actividad");

            migrationBuilder.DropColumn(
                name: "actividadid",
                table: "Tecnicos_Actividad");

            migrationBuilder.AlterColumn<long>(
                name: "id_actividad",
                table: "Tecnicos_Actividad",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(int));

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Actividad_id_actividad",
                table: "Tecnicos_Actividad",
                column: "id_actividad");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Users_Tecnicos_Actividad_Cat",
                table: "Tecnicos_Actividad",
                column: "id_actividad",
                principalTable: "Cat_Actividad",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Users_Tecnicos_Actividad_Cat",
                table: "Tecnicos_Actividad");

            migrationBuilder.DropIndex(
                name: "IX_Tecnicos_Actividad_id_actividad",
                table: "Tecnicos_Actividad");

            migrationBuilder.AlterColumn<int>(
                name: "id_actividad",
                table: "Tecnicos_Actividad",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AddColumn<int>(
                name: "actividadid",
                table: "Tecnicos_Actividad",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Actividad_actividadid",
                table: "Tecnicos_Actividad",
                column: "actividadid");

            migrationBuilder.AddForeignKey(
                name: "FK_Tecnicos_Actividad_Cat_tipo_servicio_actividadid",
                table: "Tecnicos_Actividad",
                column: "actividadid",
                principalTable: "Cat_tipo_servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
