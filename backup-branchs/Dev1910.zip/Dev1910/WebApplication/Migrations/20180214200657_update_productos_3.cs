﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class update_productos_3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cat_Imagenes_Producto");

            migrationBuilder.DropTable(
                name: "Cat_SubLinea_Producto");

            migrationBuilder.DropTable(
                name: "Cat_Sugeridos_Producto");

            migrationBuilder.DropTable(
                name: "Cat_Productos");

            migrationBuilder.DropTable(
                name: "Cat_Linea_Producto");

            migrationBuilder.DropTable(
                name: "Cat_Categoria_Producto");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_Categoria_Producto",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(nullable: true),
                    estatus = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Categoria_Producto", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_SubLinea_Producto",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(nullable: true),
                    estatus = table.Column<bool>(nullable: false),
                    id_linea = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_SubLinea_Producto", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Linea_Producto",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(nullable: true),
                    estatus = table.Column<bool>(nullable: false),
                    id_categoriaid = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Linea_Producto", x => x.id);
                    table.ForeignKey(
                        name: "FK_Cat_Linea_Producto_Cat_Categoria_Producto_id_categoriaid",
                        column: x => x.id_categoriaid,
                        principalTable: "Cat_Categoria_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Productos",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actualizado = table.Column<DateTime>(nullable: false),
                    actualizadopor = table.Column<long>(nullable: false),
                    atributus = table.Column<string>(nullable: true),
                    creado = table.Column<DateTime>(nullable: false),
                    creadopor = table.Column<long>(nullable: false),
                    descripcion_corta = table.Column<string>(nullable: true),
                    descripcion_larga = table.Column<string>(nullable: true),
                    estatus = table.Column<bool>(nullable: false),
                    ficha_tecnica = table.Column<string>(nullable: true),
                    id_categoria = table.Column<int>(nullable: false),
                    id_linea = table.Column<int>(nullable: false),
                    id_sublinea = table.Column<int>(nullable: false),
                    modelo = table.Column<string>(nullable: true),
                    nombre = table.Column<string>(nullable: true),
                    precio_con_iva = table.Column<string>(nullable: true),
                    precio_sin_iva = table.Column<string>(nullable: true),
                    sku = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Productos", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Categoria_Producto",
                        column: x => x.id_categoria,
                        principalTable: "Cat_Categoria_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Linea_Producto",
                        column: x => x.id_linea,
                        principalTable: "Cat_Linea_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Imagenes_Producto",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(nullable: false),
                    id_producto = table.Column<int>(nullable: false),
                    url = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Imagenes_Producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Imagen_Producto",
                        column: x => x.id_producto,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Sugeridos_Producto",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(nullable: false),
                    id_producto = table.Column<int>(nullable: false),
                    sku_sugerido = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Sugeridos_Producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Sugeridos_Producto",
                        column: x => x.id_producto,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Imagenes_Producto_id_producto",
                table: "Cat_Imagenes_Producto",
                column: "id_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Linea_Producto_id_categoriaid",
                table: "Cat_Linea_Producto",
                column: "id_categoriaid");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Productos_id_categoria",
                table: "Cat_Productos",
                column: "id_categoria");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Productos_id_linea",
                table: "Cat_Productos",
                column: "id_linea");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Sugeridos_Producto_id_producto",
                table: "Cat_Sugeridos_Producto",
                column: "id_producto");
        }
    }
}
