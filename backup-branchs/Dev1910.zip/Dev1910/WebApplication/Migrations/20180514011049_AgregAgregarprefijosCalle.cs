﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregAgregarprefijosCalle : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "id_prefijo_calle",
                table: "DatosFiscales",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "id_prefijo_calle",
                table: "Cat_Direccion",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_prefijo_calle",
                table: "DatosFiscales");

            migrationBuilder.DropColumn(
                name: "id_prefijo_calle",
                table: "Cat_Direccion");
        }
    }
}
