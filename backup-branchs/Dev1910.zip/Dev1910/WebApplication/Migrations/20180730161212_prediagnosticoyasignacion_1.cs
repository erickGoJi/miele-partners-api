﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class prediagnosticoyasignacion_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Prediagnostico_Refacciones_Cat_Materiales_materialesid",
                table: "Prediagnostico_Refacciones");

            migrationBuilder.DropIndex(
                name: "IX_Prediagnostico_Refacciones_materialesid",
                table: "Prediagnostico_Refacciones");

            migrationBuilder.DropColumn(
                name: "materialesid",
                table: "Prediagnostico_Refacciones");

            migrationBuilder.AddColumn<bool>(
                name: "si_acepto",
                table: "Prediagnostico_Refacciones",
                type: "bit",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "si_acepto",
                table: "Prediagnostico_Refacciones");

            migrationBuilder.AddColumn<int>(
                name: "materialesid",
                table: "Prediagnostico_Refacciones",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Prediagnostico_Refacciones_materialesid",
                table: "Prediagnostico_Refacciones",
                column: "materialesid");

            migrationBuilder.AddForeignKey(
                name: "FK_Prediagnostico_Refacciones_Cat_Materiales_materialesid",
                table: "Prediagnostico_Refacciones",
                column: "materialesid",
                principalTable: "Cat_Materiales",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
