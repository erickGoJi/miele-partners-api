﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class repuesto_tecnico : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Piezas_Repuesto_Rel_servicio_Refaccion_refaccionesid",
                table: "Piezas_Repuesto");

            migrationBuilder.DropForeignKey(
                name: "FK_Piezas_Repuesto_Tecnico_Rel_servicio_Refaccion_refaccionesid",
                table: "Piezas_Repuesto_Tecnico");

            migrationBuilder.DropIndex(
                name: "IX_Piezas_Repuesto_Tecnico_refaccionesid",
                table: "Piezas_Repuesto_Tecnico");

            migrationBuilder.DropIndex(
                name: "IX_Piezas_Repuesto_refaccionesid",
                table: "Piezas_Repuesto");

            migrationBuilder.DropColumn(
                name: "refaccionesid",
                table: "Piezas_Repuesto_Tecnico");

            migrationBuilder.DropColumn(
                name: "refaccionesid",
                table: "Piezas_Repuesto");

            migrationBuilder.CreateIndex(
                name: "IX_Piezas_Repuesto_Tecnico_id_rel_servicio_refaccion",
                table: "Piezas_Repuesto_Tecnico",
                column: "id_rel_servicio_refaccion");

            migrationBuilder.CreateIndex(
                name: "IX_Piezas_Repuesto_id_rel_servicio_refaccion",
                table: "Piezas_Repuesto",
                column: "id_rel_servicio_refaccion");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Piezas_Repuesto_Rel_Servicio_Producto",
                table: "Piezas_Repuesto",
                column: "id_rel_servicio_refaccion",
                principalTable: "Rel_servicio_Refaccion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Piezas_Repuesto_Tecnico_Rel_Servicio_Producto",
                table: "Piezas_Repuesto_Tecnico",
                column: "id_rel_servicio_refaccion",
                principalTable: "Rel_servicio_Refaccion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Piezas_Repuesto_Rel_Servicio_Producto",
                table: "Piezas_Repuesto");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Piezas_Repuesto_Tecnico_Rel_Servicio_Producto",
                table: "Piezas_Repuesto_Tecnico");

            migrationBuilder.DropIndex(
                name: "IX_Piezas_Repuesto_Tecnico_id_rel_servicio_refaccion",
                table: "Piezas_Repuesto_Tecnico");

            migrationBuilder.DropIndex(
                name: "IX_Piezas_Repuesto_id_rel_servicio_refaccion",
                table: "Piezas_Repuesto");

            migrationBuilder.AddColumn<int>(
                name: "refaccionesid",
                table: "Piezas_Repuesto_Tecnico",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "refaccionesid",
                table: "Piezas_Repuesto",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Piezas_Repuesto_Tecnico_refaccionesid",
                table: "Piezas_Repuesto_Tecnico",
                column: "refaccionesid");

            migrationBuilder.CreateIndex(
                name: "IX_Piezas_Repuesto_refaccionesid",
                table: "Piezas_Repuesto",
                column: "refaccionesid");

            migrationBuilder.AddForeignKey(
                name: "FK_Piezas_Repuesto_Rel_servicio_Refaccion_refaccionesid",
                table: "Piezas_Repuesto",
                column: "refaccionesid",
                principalTable: "Rel_servicio_Refaccion",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Piezas_Repuesto_Tecnico_Rel_servicio_Refaccion_refaccionesid",
                table: "Piezas_Repuesto_Tecnico",
                column: "refaccionesid",
                principalTable: "Rel_servicio_Refaccion",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
