﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class agregar_promo_prod_coti : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "id_tipo_beneficio",
                table: "promocion",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "Cotizacion_Promocion",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_cotizacion = table.Column<long>(type: "bigint", nullable: false),
                    id_promocion = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cotizacion_Promocion", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_producto_promocion_cotizacion",
                        column: x => x.id_cotizacion,
                        principalTable: "Cotizaciones",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_producto_promocion_promocion",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Producto_Producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_producto = table.Column<long>(type: "bigint", nullable: false),
                    id_promocion = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Producto_Producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_producto_promocion_cat_productos",
                        column: x => x.id_producto,
                        principalTable: "Cat_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_producto_promocion_promociones",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cotizacion_Promocion_id_cotizacion",
                table: "Cotizacion_Promocion",
                column: "id_cotizacion");

            migrationBuilder.CreateIndex(
                name: "IX_Cotizacion_Promocion_id_promocion",
                table: "Cotizacion_Promocion",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_Producto_Producto_id_producto",
                table: "Producto_Producto",
                column: "id_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Producto_Producto_id_promocion",
                table: "Producto_Producto",
                column: "id_promocion");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cotizacion_Promocion");

            migrationBuilder.DropTable(
                name: "Producto_Producto");

            migrationBuilder.DropColumn(
                name: "id_tipo_beneficio",
                table: "promocion");
        }
    }
}
