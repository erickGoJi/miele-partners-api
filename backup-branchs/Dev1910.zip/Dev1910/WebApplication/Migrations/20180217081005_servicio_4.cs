﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicio_4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "id_estatus_servicio",
                table: "Servicio",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_estatus_servicio",
                table: "Servicio",
                column: "id_estatus_servicio");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Servicio_Estatus",
                table: "Servicio",
                column: "id_estatus_servicio",
                principalTable: "Cat_estatus_servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Servicio_Estatus",
                table: "Servicio");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_id_estatus_servicio",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "id_estatus_servicio",
                table: "Servicio");
        }
    }
}
