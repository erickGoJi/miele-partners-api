﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class ModifcarRolForCondPago6 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "siglas",
                table: "Cat_Roles",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_cuenta",
                table: "Cat_Formas_Pago",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "id_cuenta",
                table: "Cat_CondicionesPago",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "siglas",
                table: "Cat_Roles");

            migrationBuilder.DropColumn(
                name: "id_cuenta",
                table: "Cat_Formas_Pago");

            migrationBuilder.DropColumn(
                name: "id_cuenta",
                table: "Cat_CondicionesPago");
        }
    }
}
