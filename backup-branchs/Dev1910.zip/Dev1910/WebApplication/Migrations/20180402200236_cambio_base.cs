﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class cambio_base : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Servicio_Estatus",
                table: "Servicio");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_id_estatus_servicio",
                table: "Servicio");

            migrationBuilder.AddColumn<int>(
                name: "Cat_estatus_servicioid",
                table: "Servicio",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_Cat_estatus_servicioid",
                table: "Servicio",
                column: "Cat_estatus_servicioid");

            migrationBuilder.AddForeignKey(
                name: "FK_Servicio_Cat_estatus_servicio_Cat_estatus_servicioid",
                table: "Servicio",
                column: "Cat_estatus_servicioid",
                principalTable: "Cat_estatus_servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Servicio_Cat_estatus_servicio_Cat_estatus_servicioid",
                table: "Servicio");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_Cat_estatus_servicioid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "Cat_estatus_servicioid",
                table: "Servicio");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_estatus_servicio",
                table: "Servicio",
                column: "id_estatus_servicio");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Servicio_Estatus",
                table: "Servicio",
                column: "id_estatus_servicio",
                principalTable: "Cat_estatus_servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
