﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class cambios_servicio : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "nombre_tarjetahabiente",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "notarjeta",
                table: "Servicio");

            migrationBuilder.AddColumn<bool>(
                name: "garantia",
                table: "Servicio",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "pagado",
                table: "Servicio",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "pago_pendiente",
                table: "Servicio",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "Rel_servicio_Refaccion",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actividades = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    fallas = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_servicio = table.Column<long>(type: "bigint", nullable: false),
                    serviciosid = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rel_servicio_Refaccion", x => x.id);
                    table.ForeignKey(
                        name: "FK_Rel_servicio_Refaccion_Servicio_serviciosid",
                        column: x => x.serviciosid,
                        principalTable: "Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Piezas_Repuesto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    cantidad = table.Column<int>(type: "int", nullable: false),
                    id_material = table.Column<long>(type: "bigint", nullable: false),
                    id_rel_servicio_refaccion = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Piezas_Repuesto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Piezas_Repuesto_Rel_Servicio_Producto",
                        column: x => x.id_rel_servicio_refaccion,
                        principalTable: "Rel_servicio_Refaccion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Piezas_Repuesto_id_rel_servicio_refaccion",
                table: "Piezas_Repuesto",
                column: "id_rel_servicio_refaccion");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_serviciosid",
                table: "Rel_servicio_Refaccion",
                column: "serviciosid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Piezas_Repuesto");

            migrationBuilder.DropTable(
                name: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "garantia",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "pagado",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "pago_pendiente",
                table: "Servicio");

            migrationBuilder.AddColumn<string>(
                name: "nombre_tarjetahabiente",
                table: "Servicio",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "notarjeta",
                table: "Servicio",
                nullable: true);
        }
    }
}
