﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class prediagnosticoyasignacion : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "pre_diagnostico",
                table: "Servicio");

            migrationBuilder.AddColumn<bool>(
                name: "asignacion_refacciones",
                table: "Visita",
                type: "bit",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "pre_diagnostico",
                table: "Visita",
                type: "bit",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Prediagnostico",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_visita = table.Column<long>(type: "bigint", nullable: false),
                    observaciones = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    visitaid = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Prediagnostico", x => x.id);
                    table.ForeignKey(
                        name: "FK_Prediagnostico_Visita_visitaid",
                        column: x => x.visitaid,
                        principalTable: "Visita",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Prediagnostico_Refacciones",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_material = table.Column<long>(type: "bigint", nullable: false),
                    id_prediagnostico = table.Column<long>(type: "bigint", nullable: false),
                    materialesid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Prediagnostico_Refacciones", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Prediagnostico_Refacciones",
                        column: x => x.id_prediagnostico,
                        principalTable: "Prediagnostico",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Prediagnostico_Refacciones_Cat_Materiales_materialesid",
                        column: x => x.materialesid,
                        principalTable: "Cat_Materiales",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Prediagnostico_visitaid",
                table: "Prediagnostico",
                column: "visitaid");

            migrationBuilder.CreateIndex(
                name: "IX_Prediagnostico_Refacciones_id_prediagnostico",
                table: "Prediagnostico_Refacciones",
                column: "id_prediagnostico");

            migrationBuilder.CreateIndex(
                name: "IX_Prediagnostico_Refacciones_materialesid",
                table: "Prediagnostico_Refacciones",
                column: "materialesid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Prediagnostico_Refacciones");

            migrationBuilder.DropTable(
                name: "Prediagnostico");

            migrationBuilder.DropColumn(
                name: "asignacion_refacciones",
                table: "Visita");

            migrationBuilder.DropColumn(
                name: "pre_diagnostico",
                table: "Visita");

            migrationBuilder.AddColumn<bool>(
                name: "pre_diagnostico",
                table: "Servicio",
                nullable: true);
        }
    }
}
