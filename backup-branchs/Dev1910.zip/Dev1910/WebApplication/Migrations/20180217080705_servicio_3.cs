﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicio_3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Servicio",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actividades_realizar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    actualizado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    actualizadopor = table.Column<long>(type: "bigint", nullable: false),
                    cantidad = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    comprobante = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    concepto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    contacto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    creado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    creadopor = table.Column<long>(type: "bigint", nullable: false),
                    descripcion_actividades = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    factura = table.Column<bool>(type: "bit", nullable: false),
                    fecha_deposito = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    fecha_servicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    hora = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_categoria_servicio = table.Column<int>(type: "int", nullable: false),
                    id_cliente = table.Column<long>(type: "bigint", nullable: false),
                    id_direccion = table.Column<int>(type: "int", nullable: false),
                    id_distribuidor_autorizado = table.Column<long>(type: "bigint", nullable: false),
                    id_solicitado_por = table.Column<int>(type: "int", nullable: false),
                    id_solicitud_via = table.Column<int>(type: "int", nullable: false),
                    id_tecnico = table.Column<long>(type: "bigint", nullable: false),
                    id_tipo_servicio = table.Column<int>(type: "int", nullable: false),
                    no_operacion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    nombre_tarjetahabiente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    notarjeta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    terminos_condiciones = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Servicio", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Categoria_servivio",
                        column: x => x.id_categoria_servicio,
                        principalTable: "Cat_Categoria_Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Cliente",
                        column: x => x.id_cliente,
                        principalTable: "Clientes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Distribuidor_Autorizado",
                        column: x => x.id_distribuidor_autorizado,
                        principalTable: "Cat_distribuidor_autorizado",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Solicitado_Por",
                        column: x => x.id_solicitado_por,
                        principalTable: "Cat_solicitado_por",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Solicitud_Via",
                        column: x => x.id_solicitud_via,
                        principalTable: "Cat_solicitud_via",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Tecnico",
                        column: x => x.id_tecnico,
                        principalTable: "Tecnicos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_TipoServicio",
                        column: x => x.id_tipo_servicio,
                        principalTable: "Cat_tipo_servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Rel_servicio_producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cat_Productosid = table.Column<int>(type: "int", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_producto = table.Column<long>(type: "bigint", nullable: false),
                    id_servicio = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rel_servicio_producto", x => x.id);
                    table.ForeignKey(
                        name: "FK_Rel_servicio_producto_Cat_Productos_Cat_Productosid",
                        column: x => x.Cat_Productosid,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "ForeignKey_Rel_Servicio_Producto",
                        column: x => x.id_producto,
                        principalTable: "Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Rel_servicio_Refaccion",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cat_Materialesid = table.Column<int>(type: "int", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_material = table.Column<long>(type: "bigint", nullable: false),
                    id_servicio = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rel_servicio_Refaccion", x => x.id);
                    table.ForeignKey(
                        name: "FK_Rel_servicio_Refaccion_Cat_Materiales_Cat_Materialesid",
                        column: x => x.Cat_Materialesid,
                        principalTable: "Cat_Materiales",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "ForeignKey_Rel_Servicio_Refaccion",
                        column: x => x.id_material,
                        principalTable: "Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_Cat_Productosid",
                table: "Rel_servicio_producto",
                column: "Cat_Productosid");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_id_producto",
                table: "Rel_servicio_producto",
                column: "id_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_Cat_Materialesid",
                table: "Rel_servicio_Refaccion",
                column: "Cat_Materialesid");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_material",
                table: "Rel_servicio_Refaccion",
                column: "id_material");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_categoria_servicio",
                table: "Servicio",
                column: "id_categoria_servicio");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_cliente",
                table: "Servicio",
                column: "id_cliente");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_distribuidor_autorizado",
                table: "Servicio",
                column: "id_distribuidor_autorizado");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_solicitado_por",
                table: "Servicio",
                column: "id_solicitado_por");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_solicitud_via",
                table: "Servicio",
                column: "id_solicitud_via");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_tecnico",
                table: "Servicio",
                column: "id_tecnico");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_tipo_servicio",
                table: "Servicio",
                column: "id_tipo_servicio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Rel_servicio_producto");

            migrationBuilder.DropTable(
                name: "Rel_servicio_Refaccion");

            migrationBuilder.DropTable(
                name: "Servicio");
        }
    }
}
