﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios_4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_producto_Cat_Productos_productosid",
                table: "Rel_servicio_producto");

            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Productos_productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_producto_productosid",
                table: "Rel_servicio_producto");

            migrationBuilder.DropColumn(
                name: "productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "productosid",
                table: "Rel_servicio_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_producto",
                table: "Rel_servicio_Refaccion",
                column: "id_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_id_producto",
                table: "Rel_servicio_producto",
                column: "id_producto");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_producto_Producto",
                table: "Rel_servicio_producto",
                column: "id_producto",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_producto_Refaccion",
                table: "Rel_servicio_Refaccion",
                column: "id_producto",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_producto_Producto",
                table: "Rel_servicio_producto");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_producto_Refaccion",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_id_producto",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_producto_id_producto",
                table: "Rel_servicio_producto");

            migrationBuilder.AddColumn<int>(
                name: "productosid",
                table: "Rel_servicio_Refaccion",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "productosid",
                table: "Rel_servicio_producto",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_productosid",
                table: "Rel_servicio_Refaccion",
                column: "productosid");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_productosid",
                table: "Rel_servicio_producto",
                column: "productosid");

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_producto_Cat_Productos_productosid",
                table: "Rel_servicio_producto",
                column: "productosid",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Productos_productosid",
                table: "Rel_servicio_Refaccion",
                column: "productosid",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
