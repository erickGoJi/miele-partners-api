﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class datosCotizacionDuplicada : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "id_cotizacion_padre",
                table: "Cotizaciones",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<string>(
                name: "motivo_rechazo",
                table: "Cotizaciones",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "rechazada",
                table: "Cotizaciones",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_cotizacion_padre",
                table: "Cotizaciones");

            migrationBuilder.DropColumn(
                name: "motivo_rechazo",
                table: "Cotizaciones");

            migrationBuilder.DropColumn(
                name: "rechazada",
                table: "Cotizaciones");
        }
    }
}
