﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarCambiarCampopagos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_tipo_comporbnates",
                table: "formas_pago_tipos_comprobantes");

            migrationBuilder.AddColumn<int>(
                name: "id_tipo_comprobantes",
                table: "formas_pago_tipos_comprobantes",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_tipo_comprobantes",
                table: "formas_pago_tipos_comprobantes");

            migrationBuilder.AddColumn<int>(
                name: "id_tipo_comporbnates",
                table: "formas_pago_tipos_comprobantes",
                nullable: false,
                defaultValue: 0);
        }
    }
}
