﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class null_id_motivo_cierre : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Servicio_CierreCliente",
                table: "Servicio");

            migrationBuilder.AlterColumn<int>(
                name: "id_motivo_cierre",
                table: "Servicio",
                type: "int",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Servicio_CierreCliente",
                table: "Servicio",
                column: "id_motivo_cierre",
                principalTable: "Cat_Motivo_Cierre_Cliente",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Servicio_CierreCliente",
                table: "Servicio");

            migrationBuilder.AlterColumn<int>(
                name: "id_motivo_cierre",
                table: "Servicio",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Servicio_CierreCliente",
                table: "Servicio",
                column: "id_motivo_cierre",
                principalTable: "Cat_Motivo_Cierre_Cliente",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
