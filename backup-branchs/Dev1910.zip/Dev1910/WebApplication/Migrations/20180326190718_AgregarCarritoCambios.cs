﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarCarritoCambios : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Carritos_Cliente",
                table: "Productos_Carrito");

            migrationBuilder.DropIndex(
                name: "IX_Productos_Carrito_Id_Cliente",
                table: "Productos_Carrito");

            migrationBuilder.AlterColumn<DateTime>(
                name: "fecha_vaciado",
                table: "Productos_Carrito",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime));

            migrationBuilder.AlterColumn<DateTime>(
                name: "fecha_Comprado",
                table: "Productos_Carrito",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime));

            migrationBuilder.AlterColumn<long>(
                name: "Id_Cliente",
                table: "Productos_Carrito",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long));

            migrationBuilder.AddColumn<int>(
                name: "Id_cotizacion",
                table: "Productos_Carrito",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Id_cotizacion",
                table: "Productos_Carrito");

            migrationBuilder.AlterColumn<DateTime>(
                name: "fecha_vaciado",
                table: "Productos_Carrito",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "fecha_Comprado",
                table: "Productos_Carrito",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "Id_Cliente",
                table: "Productos_Carrito",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Productos_Carrito_Id_Cliente",
                table: "Productos_Carrito",
                column: "Id_Cliente");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Carritos_Cliente",
                table: "Productos_Carrito",
                column: "Id_Cliente",
                principalTable: "Clientes",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
