﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarCondicionesCreacion : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_CondicionesComerciales",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    activa = table.Column<bool>(type: "bit", nullable: false),
                    condicion_comercial = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    meses_credito = table.Column<float>(type: "real", nullable: false),
                    monto_descuento = table.Column<float>(type: "real", nullable: false),
                    num_meses_sinint = table.Column<float>(type: "real", nullable: false),
                    porcentaje_credito = table.Column<float>(type: "real", nullable: false),
                    porcentaje_descuento = table.Column<float>(type: "real", nullable: false),
                    tipo = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_CondicionesComerciales", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cat_CondicionesComerciales");
        }
    }
}
