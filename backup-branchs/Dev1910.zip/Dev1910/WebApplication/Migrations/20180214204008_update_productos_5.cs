﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class update_productos_5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Linea_Producto",
                table: "Cat_Productos");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Sublinea_Producto",
                table: "Cat_Productos");

            migrationBuilder.AlterColumn<int>(
                name: "id_sublinea",
                table: "Cat_Productos",
                type: "int",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AlterColumn<int>(
                name: "id_linea",
                table: "Cat_Productos",
                type: "int",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Linea_Producto",
                table: "Cat_Productos",
                column: "id_linea",
                principalTable: "Cat_Linea_Producto",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Sublinea_Producto",
                table: "Cat_Productos",
                column: "id_sublinea",
                principalTable: "Cat_SubLinea_Producto",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Linea_Producto",
                table: "Cat_Productos");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Sublinea_Producto",
                table: "Cat_Productos");

            migrationBuilder.AlterColumn<int>(
                name: "id_sublinea",
                table: "Cat_Productos",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "id_linea",
                table: "Cat_Productos",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Linea_Producto",
                table: "Cat_Productos",
                column: "id_linea",
                principalTable: "Cat_Linea_Producto",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Sublinea_Producto",
                table: "Cat_Productos",
                column: "id_sublinea",
                principalTable: "Cat_SubLinea_Producto",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
