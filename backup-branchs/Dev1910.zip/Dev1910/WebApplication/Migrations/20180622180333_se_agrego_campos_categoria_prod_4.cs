﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class se_agrego_campos_categoria_prod_4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "precio_hora_tecnico",
                table: "Cat_Categoria_Producto",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "precio_visita",
                table: "Cat_Categoria_Producto",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "precio_hora_tecnico",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "precio_visita",
                table: "Cat_Categoria_Producto");
        }
    }
}
