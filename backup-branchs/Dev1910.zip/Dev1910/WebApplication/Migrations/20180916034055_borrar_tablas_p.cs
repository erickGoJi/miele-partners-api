﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class borrar_tablas_p : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "afectacion_cc");

            migrationBuilder.DropTable(
                name: "beneficio_desc");

            migrationBuilder.DropTable(
                name: "beneficio_msi");

            migrationBuilder.DropTable(
                name: "beneficio_productos");

            migrationBuilder.DropTable(
                name: "beneficios_promocion");

            migrationBuilder.DropTable(
                name: "entidades_excluidas");

            migrationBuilder.DropTable(
                name: "entidades_participantes");

            migrationBuilder.DropTable(
                name: "productos_condicion");

            migrationBuilder.DropTable(
                name: "condiones_comerciales_sucursal");

            migrationBuilder.DropTable(
                name: "cat_msi");

            migrationBuilder.DropTable(
                name: "cat_beneficios");

            migrationBuilder.DropTable(
                name: "cat_tipo_entidades");

            migrationBuilder.DropTable(
                name: "promocion");

            migrationBuilder.DropTable(
                name: "cat_tipo_condicion");

            migrationBuilder.DropTable(
                name: "cat_tipos_herencia");

            migrationBuilder.DropColumn(
                name: "iva_precio_descuento",
                table: "Cotizacion_Producto");

            migrationBuilder.DropColumn(
                name: "iva_precio_lista",
                table: "Cotizacion_Producto");

            migrationBuilder.DropColumn(
                name: "precio_descuento",
                table: "Cotizacion_Producto");

            migrationBuilder.DropColumn(
                name: "precio_lista",
                table: "Cotizacion_Producto");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<float>(
                name: "iva_precio_descuento",
                table: "Cotizacion_Producto",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "iva_precio_lista",
                table: "Cotizacion_Producto",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "precio_descuento",
                table: "Cotizacion_Producto",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "precio_lista",
                table: "Cotizacion_Producto",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.CreateTable(
                name: "cat_beneficios",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    beneficio = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cat_beneficios", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "cat_msi",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_msi = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cat_msi", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "cat_tipo_condicion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    tipo_condicion = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cat_tipo_condicion", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "cat_tipo_entidades",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    tipo_entidad = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cat_tipo_entidades", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "cat_tipos_herencia",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    tipo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cat_tipos_herencia", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "condiones_comerciales_sucursal",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cat_SubLinea_Productoid = table.Column<int>(nullable: true),
                    Cat_SucursalesId = table.Column<int>(nullable: true),
                    condicion = table.Column<int>(nullable: false),
                    id_Cat_SubLinea_Producto = table.Column<int>(nullable: false),
                    id_Cat_Sucursales = table.Column<int>(nullable: false),
                    margen = table.Column<float>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_condiones_comerciales_sucursal", x => x.id);
                    table.ForeignKey(
                        name: "FK_condiones_comerciales_sucursal_Cat_SubLinea_Producto_Cat_SubLinea_Productoid",
                        column: x => x.Cat_SubLinea_Productoid,
                        principalTable: "Cat_SubLinea_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_condiones_comerciales_sucursal_Cat_Sucursales_Cat_SucursalesId",
                        column: x => x.Cat_SucursalesId,
                        principalTable: "Cat_Sucursales",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "promocion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    fecha_hora_fin = table.Column<string>(nullable: true),
                    fecha_hora_inicio = table.Column<string>(nullable: true),
                    id_cat_tipo_condicion = table.Column<int>(nullable: false),
                    id_tipos_herencia_promo = table.Column<int>(nullable: false),
                    monto_condicion = table.Column<int>(nullable: false),
                    nombre = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_promocion", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_promocion_condicion2",
                        column: x => x.id_cat_tipo_condicion,
                        principalTable: "cat_tipo_condicion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_promocion_herencia2",
                        column: x => x.id_tipos_herencia_promo,
                        principalTable: "cat_tipos_herencia",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "afectacion_cc",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_condiones_comerciales_sucursal = table.Column<int>(nullable: false),
                    id_promocion = table.Column<int>(nullable: false),
                    margen = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_afectacion_cc", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_afectacioncc_condiones_comerciales_sucursal2",
                        column: x => x.id_condiones_comerciales_sucursal,
                        principalTable: "condiones_comerciales_sucursal",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_beneficioproductos_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "beneficio_desc",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    cantidad = table.Column<int>(nullable: false),
                    es_porcentaje = table.Column<bool>(nullable: false),
                    id_promocion = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_beneficio_desc", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_beneficiodesc_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "beneficio_msi",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_cat_msi = table.Column<int>(nullable: false),
                    id_promocion = table.Column<int>(nullable: false),
                    promocionid = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_beneficio_msi", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_beneficiomsi_catmsi2",
                        column: x => x.id_cat_msi,
                        principalTable: "cat_msi",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_beneficio_msi_promocion_promocionid",
                        column: x => x.promocionid,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "beneficio_productos",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    cantidad = table.Column<int>(nullable: false),
                    id_producto = table.Column<int>(nullable: false),
                    id_promocion = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_beneficio_productos", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_beneficioproductos_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "beneficios_promocion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_cat_beneficios = table.Column<int>(nullable: false),
                    id_promocion = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_beneficios_promocion", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_beneficiospromocion_cattipoentidades2",
                        column: x => x.id_cat_beneficios,
                        principalTable: "cat_beneficios",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_beneficiospromocion_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "entidades_excluidas",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_entidad = table.Column<int>(nullable: false),
                    id_promocion = table.Column<int>(nullable: false),
                    id_tipo_entidad = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_entidades_excluidas", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_entidadesexcluidas_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_entidades_excluidas_cattipoentidades2",
                        column: x => x.id_tipo_entidad,
                        principalTable: "cat_tipo_entidades",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "entidades_participantes",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_entidad = table.Column<int>(nullable: false),
                    id_promocion = table.Column<int>(nullable: false),
                    id_tipo_entidad = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_entidades_participantes", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_entidadesparticipantes_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_entidadesparticipantes_cattipoentidades2",
                        column: x => x.id_tipo_entidad,
                        principalTable: "cat_tipo_entidades",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "productos_condicion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    cantidad = table.Column<int>(nullable: false),
                    id_producto = table.Column<int>(nullable: false),
                    id_promocion = table.Column<int>(nullable: false),
                    id_tipo_categoria = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_productos_condicion", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_productoscondicion_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_afectacion_cc_id_condiones_comerciales_sucursal",
                table: "afectacion_cc",
                column: "id_condiones_comerciales_sucursal");

            migrationBuilder.CreateIndex(
                name: "IX_afectacion_cc_id_promocion",
                table: "afectacion_cc",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_beneficio_desc_id_promocion",
                table: "beneficio_desc",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_beneficio_msi_id_cat_msi",
                table: "beneficio_msi",
                column: "id_cat_msi");

            migrationBuilder.CreateIndex(
                name: "IX_beneficio_msi_promocionid",
                table: "beneficio_msi",
                column: "promocionid");

            migrationBuilder.CreateIndex(
                name: "IX_beneficio_productos_id_promocion",
                table: "beneficio_productos",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_beneficios_promocion_id_cat_beneficios",
                table: "beneficios_promocion",
                column: "id_cat_beneficios");

            migrationBuilder.CreateIndex(
                name: "IX_beneficios_promocion_id_promocion",
                table: "beneficios_promocion",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_condiones_comerciales_sucursal_Cat_SubLinea_Productoid",
                table: "condiones_comerciales_sucursal",
                column: "Cat_SubLinea_Productoid");

            migrationBuilder.CreateIndex(
                name: "IX_condiones_comerciales_sucursal_Cat_SucursalesId",
                table: "condiones_comerciales_sucursal",
                column: "Cat_SucursalesId");

            migrationBuilder.CreateIndex(
                name: "IX_entidades_excluidas_id_promocion",
                table: "entidades_excluidas",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_entidades_excluidas_id_tipo_entidad",
                table: "entidades_excluidas",
                column: "id_tipo_entidad");

            migrationBuilder.CreateIndex(
                name: "IX_entidades_participantes_id_promocion",
                table: "entidades_participantes",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_entidades_participantes_id_tipo_entidad",
                table: "entidades_participantes",
                column: "id_tipo_entidad");

            migrationBuilder.CreateIndex(
                name: "IX_productos_condicion_id_promocion",
                table: "productos_condicion",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_promocion_id_cat_tipo_condicion",
                table: "promocion",
                column: "id_cat_tipo_condicion");

            migrationBuilder.CreateIndex(
                name: "IX_promocion_id_tipos_herencia_promo",
                table: "promocion",
                column: "id_tipos_herencia_promo");
        }
    }
}
