﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarPermisosBD1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Permisos_Cotizacion");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Permisos_Cotizacion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_Canal = table.Column<long>(nullable: false),
                    id_estatus_cotizacion = table.Column<int>(nullable: false),
                    id_rol = table.Column<long>(nullable: false),
                    inhabilitado = table.Column<bool>(nullable: false),
                    permiso = table.Column<string>(nullable: true),
                    visible = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Permisos_Cotizacion", x => x.id);
                });
        }
    }
}
