﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class producto_respuesta_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_pregunta",
                table: "Producto_Check_List_Respuestas");

            migrationBuilder.AddColumn<int>(
                name: "id_pregunta",
                table: "Check_List_Respuestas",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_pregunta",
                table: "Check_List_Respuestas");

            migrationBuilder.AddColumn<int>(
                name: "id_pregunta",
                table: "Producto_Check_List_Respuestas",
                nullable: false,
                defaultValue: 0);
        }
    }
}
