﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class DeleteAccesorios : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cat_Accesorios_Relacionados");

            migrationBuilder.DropTable(
                name: "Cat_Estatus_Cotizacion");

            migrationBuilder.DropTable(
                name: "Cat_Imagenes_Accesosrios");

            migrationBuilder.DropTable(
                name: "Cat_Accesorios");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_Accesorios",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actualizado = table.Column<DateTime>(nullable: false),
                    actualizadopor = table.Column<long>(nullable: false),
                    atributos = table.Column<string>(nullable: true),
                    creado = table.Column<DateTime>(nullable: false),
                    creadopor = table.Column<long>(nullable: false),
                    descripcion_corta = table.Column<string>(nullable: true),
                    descripcion_larga = table.Column<string>(nullable: true),
                    estatus = table.Column<bool>(nullable: false),
                    ficha_tecnica = table.Column<string>(nullable: true),
                    modelo = table.Column<string>(nullable: true),
                    nombre = table.Column<string>(nullable: true),
                    precio_con_iva = table.Column<string>(nullable: true),
                    precio_sin_iva = table.Column<string>(nullable: true),
                    sku = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Accesorios", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Estatus_Cotizacion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Estatus_en = table.Column<string>(nullable: true),
                    Estatus_es = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Estatus_Cotizacion", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Accesorios_Relacionados",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(nullable: false),
                    id_Accesorio = table.Column<int>(nullable: false),
                    sku_sugerido = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Accesorios_Relacionados", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Accesorios_relacionados",
                        column: x => x.id_Accesorio,
                        principalTable: "Cat_Accesorios",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Imagenes_Accesosrios",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(nullable: false),
                    id_Accesorio = table.Column<int>(nullable: false),
                    url = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Imagenes_Accesosrios", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Imagen_Accesorios",
                        column: x => x.id_Accesorio,
                        principalTable: "Cat_Accesorios",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Accesorios_Relacionados_id_Accesorio",
                table: "Cat_Accesorios_Relacionados",
                column: "id_Accesorio");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Imagenes_Accesosrios_id_Accesorio",
                table: "Cat_Imagenes_Accesosrios",
                column: "id_Accesorio");
        }
    }
}
