﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicio_5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_producto_Cat_Productos_Cat_Productosid",
                table: "Rel_servicio_producto");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Servicio_Producto",
                table: "Rel_servicio_producto");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Servicio_Refaccion",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_id_material",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_producto_Cat_Productosid",
                table: "Rel_servicio_producto");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_producto_id_producto",
                table: "Rel_servicio_producto");

            migrationBuilder.DropColumn(
                name: "Cat_Productosid",
                table: "Rel_servicio_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_servicio",
                table: "Rel_servicio_Refaccion",
                column: "id_servicio");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_id_servicio",
                table: "Rel_servicio_producto",
                column: "id_servicio");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Servicio_Producto",
                table: "Rel_servicio_producto",
                column: "id_servicio",
                principalTable: "Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Servicio_Refaccion",
                table: "Rel_servicio_Refaccion",
                column: "id_servicio",
                principalTable: "Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Servicio_Producto",
                table: "Rel_servicio_producto");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Servicio_Refaccion",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_id_servicio",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_producto_id_servicio",
                table: "Rel_servicio_producto");

            migrationBuilder.AddColumn<int>(
                name: "Cat_Productosid",
                table: "Rel_servicio_producto",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_material",
                table: "Rel_servicio_Refaccion",
                column: "id_material");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_Cat_Productosid",
                table: "Rel_servicio_producto",
                column: "Cat_Productosid");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_id_producto",
                table: "Rel_servicio_producto",
                column: "id_producto");

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_producto_Cat_Productos_Cat_Productosid",
                table: "Rel_servicio_producto",
                column: "Cat_Productosid",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Servicio_Producto",
                table: "Rel_servicio_producto",
                column: "id_producto",
                principalTable: "Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Servicio_Refaccion",
                table: "Rel_servicio_Refaccion",
                column: "id_material",
                principalTable: "Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
