﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class se_agrego_campos_categoria_prod_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "precio_hora_tecnico",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "precio_visita",
                table: "Cat_Categoria_Producto");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "precio_hora_tecnico",
                table: "Cat_Categoria_Producto",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "precio_visita",
                table: "Cat_Categoria_Producto",
                nullable: true);
        }
    }
}
