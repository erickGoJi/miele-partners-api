﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class llaves_cliente_producto_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cliente_Productos");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cliente_Productos",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FechaCompra = table.Column<DateTime>(nullable: false),
                    FinGarantia = table.Column<DateTime>(nullable: false),
                    Id_Cliente = table.Column<long>(nullable: false),
                    Id_EsatusCompra = table.Column<long>(nullable: false),
                    Id_Producto = table.Column<int>(nullable: false),
                    NoOrdenCompra = table.Column<string>(nullable: true),
                    NoPoliza = table.Column<string>(nullable: true),
                    actualizado = table.Column<DateTime>(nullable: false),
                    actualizadopor = table.Column<long>(nullable: false),
                    creado = table.Column<DateTime>(nullable: false),
                    creadopor = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cliente_Productos", x => x.Id);
                    table.ForeignKey(
                        name: "ForeignKey_Cliente_Producto",
                        column: x => x.Id_Cliente,
                        principalTable: "Clientes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Cliente_Producto_Estatus",
                        column: x => x.Id_EsatusCompra,
                        principalTable: "Cat_Estatus_Compra",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Cliente_Producto_Producto",
                        column: x => x.Id_Producto,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Id_Cliente",
                table: "Cliente_Productos",
                column: "Id_Cliente");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Id_EsatusCompra",
                table: "Cliente_Productos",
                column: "Id_EsatusCompra");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Id_Producto",
                table: "Cliente_Productos",
                column: "Id_Producto");
        }
    }
}
