﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicio_6 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Materiales_Cat_Materialesid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_Cat_Materialesid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "Cat_Materialesid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.AddColumn<int>(
                name: "cantidad",
                table: "Rel_servicio_Refaccion",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "cantidad",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.AddColumn<int>(
                name: "Cat_Materialesid",
                table: "Rel_servicio_Refaccion",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_Cat_Materialesid",
                table: "Rel_servicio_Refaccion",
                column: "Cat_Materialesid");

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Materiales_Cat_Materialesid",
                table: "Rel_servicio_Refaccion",
                column: "Cat_Materialesid",
                principalTable: "Cat_Materiales",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
