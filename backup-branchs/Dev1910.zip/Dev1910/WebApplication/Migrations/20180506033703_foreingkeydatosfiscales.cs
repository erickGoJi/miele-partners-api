﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class foreingkeydatosfiscales : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "id_cliente",
                table: "DatosFiscales",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(int));

            migrationBuilder.CreateIndex(
                name: "IX_DatosFiscales_id_cliente",
                table: "DatosFiscales",
                column: "id_cliente");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_DatosFiscales_Cliente",
                table: "DatosFiscales",
                column: "id_cliente",
                principalTable: "Clientes",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_DatosFiscales_Cliente",
                table: "DatosFiscales");

            migrationBuilder.DropIndex(
                name: "IX_DatosFiscales_id_cliente",
                table: "DatosFiscales");

            migrationBuilder.AlterColumn<int>(
                name: "id_cliente",
                table: "DatosFiscales",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint");
        }
    }
}
