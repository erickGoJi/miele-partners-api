﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class agregar_cierrecliente : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "id_motivo_cierre",
                table: "Servicio",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Cat_Motivo_Cierre_Cliente",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_motivo_cierre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Motivo_Cierre_Cliente", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_motivo_cierre",
                table: "Servicio",
                column: "id_motivo_cierre");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Servicio_CierreCliente",
                table: "Servicio",
                column: "id_motivo_cierre",
                principalTable: "Cat_Motivo_Cierre_Cliente",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Servicio_CierreCliente",
                table: "Servicio");

            migrationBuilder.DropTable(
                name: "Cat_Motivo_Cierre_Cliente");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_id_motivo_cierre",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "id_motivo_cierre",
                table: "Servicio");
        }
    }
}
