﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class cambios_tecnicos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Tecnicos_Producto",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_categoria_producto = table.Column<int>(type: "int", nullable: false),
                    id_user = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tecnicos_Producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Producto_Cat",
                        column: x => x.id_categoria_producto,
                        principalTable: "Cat_Categoria_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Productos",
                        column: x => x.id_user,
                        principalTable: "Tecnicos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Producto_id_categoria_producto",
                table: "Tecnicos_Producto",
                column: "id_categoria_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Producto_id_user",
                table: "Tecnicos_Producto",
                column: "id_user");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tecnicos_Producto");
        }
    }
}
