﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class agregrar_idvisita1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_vista",
                table: "Check_List_Respuestas");

            migrationBuilder.AddColumn<int>(
                name: "id_visita",
                table: "Check_List_Respuestas",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_visita",
                table: "Check_List_Respuestas");

            migrationBuilder.AddColumn<int>(
                name: "id_vista",
                table: "Check_List_Respuestas",
                nullable: false,
                defaultValue: 0);
        }
    }
}
