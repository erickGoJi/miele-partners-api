﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class Addsucursales2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Cat_Sucrusales",
                table: "Cat_Sucrusales");

            migrationBuilder.RenameTable(
                name: "Cat_Sucrusales",
                newName: "Cat_Sucursales");

            migrationBuilder.RenameIndex(
                name: "IX_Cat_Sucrusales_Id_Cuenta",
                table: "Cat_Sucursales",
                newName: "IX_Cat_Sucursales_Id_Cuenta");

            migrationBuilder.AddColumn<int>(
                name: "id_Sucursales",
                table: "Users",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Cat_Sucursales",
                type: "int",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                .OldAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Cat_Sucursales",
                table: "Cat_Sucursales",
                column: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Cat_Sucursales",
                table: "Cat_Sucursales");

            migrationBuilder.DropColumn(
                name: "id_Sucursales",
                table: "Users");

            migrationBuilder.RenameTable(
                name: "Cat_Sucursales",
                newName: "Cat_Sucrusales");

            migrationBuilder.RenameIndex(
                name: "IX_Cat_Sucursales_Id_Cuenta",
                table: "Cat_Sucrusales",
                newName: "IX_Cat_Sucrusales_Id_Cuenta");

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Cat_Sucrusales",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn)
                .OldAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Cat_Sucrusales",
                table: "Cat_Sucrusales",
                column: "Id");
        }
    }
}
