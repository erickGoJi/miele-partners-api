﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class coordenadas : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "latitud_fin",
                table: "Visita",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "latitud_inicio",
                table: "Visita",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "longitud_fin",
                table: "Visita",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "longitud_inicio",
                table: "Visita",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "latitud_fin",
                table: "Visita");

            migrationBuilder.DropColumn(
                name: "latitud_inicio",
                table: "Visita");

            migrationBuilder.DropColumn(
                name: "longitud_fin",
                table: "Visita");

            migrationBuilder.DropColumn(
                name: "longitud_inicio",
                table: "Visita");
        }
    }
}
