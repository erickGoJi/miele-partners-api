﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class horas_tecnico : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "horas_tecnico",
                table: "Cat_Productos",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "precio_hora",
                table: "Cat_Productos",
                type: "decimal(18, 2)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "horas_tecnico",
                table: "Cat_Productos");

            migrationBuilder.DropColumn(
                name: "precio_hora",
                table: "Cat_Productos");
        }
    }
}
