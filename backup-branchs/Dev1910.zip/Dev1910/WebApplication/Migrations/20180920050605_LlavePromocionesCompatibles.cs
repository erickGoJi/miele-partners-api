﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class LlavePromocionesCompatibles : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_promocion_1",
                table: "promociones_compatibles");

            migrationBuilder.AddColumn<int>(
                name: "id_promocion",
                table: "promociones_compatibles",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_promociones_compatibles_id_promocion",
                table: "promociones_compatibles",
                column: "id_promocion");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_5promocompatibles1_promocion2",
                table: "promociones_compatibles",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_5promocompatibles1_promocion2",
                table: "promociones_compatibles");

            migrationBuilder.DropIndex(
                name: "IX_promociones_compatibles_id_promocion",
                table: "promociones_compatibles");

            migrationBuilder.DropColumn(
                name: "id_promocion",
                table: "promociones_compatibles");

            migrationBuilder.AddColumn<int>(
                name: "id_promocion_1",
                table: "promociones_compatibles",
                nullable: false,
                defaultValue: 0);
        }
    }
}
