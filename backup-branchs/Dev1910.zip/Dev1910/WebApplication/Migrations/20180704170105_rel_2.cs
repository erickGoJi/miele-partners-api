﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class rel_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Users_Tecnicos_Actividad_Cat",
                table: "Tecnicos_Actividad");

            migrationBuilder.DropIndex(
                name: "IX_Tecnicos_Actividad_id_actividad",
                table: "Tecnicos_Actividad");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Actividad_id_actividad",
                table: "Tecnicos_Actividad",
                column: "id_actividad");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Users_Tecnicos_Actividad_Cat",
                table: "Tecnicos_Actividad",
                column: "id_actividad",
                principalTable: "Cat_Actividad",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
