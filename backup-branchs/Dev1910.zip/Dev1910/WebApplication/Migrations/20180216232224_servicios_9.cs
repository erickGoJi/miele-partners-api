﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios_9 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Rel_servicio_Refaccion");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Rel_servicio_Refaccion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cat_Productosid = table.Column<int>(nullable: true),
                    estatus = table.Column<bool>(nullable: false),
                    id_material = table.Column<int>(nullable: false),
                    id_servicio = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rel_servicio_Refaccion", x => x.id);
                    table.ForeignKey(
                        name: "FK_Rel_servicio_Refaccion_Cat_Productos_Cat_Productosid",
                        column: x => x.Cat_Productosid,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "ForeignKey_producto_Refaccion",
                        column: x => x.id_material,
                        principalTable: "Cat_Materiales",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Refaccion",
                        column: x => x.id_servicio,
                        principalTable: "Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_Cat_Productosid",
                table: "Rel_servicio_Refaccion",
                column: "Cat_Productosid");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_material",
                table: "Rel_servicio_Refaccion",
                column: "id_material");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_servicio",
                table: "Rel_servicio_Refaccion",
                column: "id_servicio");
        }
    }
}
