﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_distribuidor_autorizado",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_distribuidor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_distribuidor_autorizado", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_estatus_servicio",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_estatus_servicio = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_estatus_servicio", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_solicitado_por",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_solicitado_por = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_solicitado_por", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_solicitud_via",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_solicitud_via = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_solicitud_via", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_tipo_servicio",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_tipo_servicio = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_tipo_servicio", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Servicio",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cat_Materialesid = table.Column<int>(type: "int", nullable: true),
                    actividades_realizar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    actualizado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    actualizadopor = table.Column<long>(type: "bigint", nullable: false),
                    cantidad = table.Column<decimal>(type: "decimal(18, 2)", nullable: false),
                    categoria_servicio = table.Column<int>(type: "int", nullable: false),
                    clienteid = table.Column<long>(type: "bigint", nullable: true),
                    comprobante = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    concepto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    contacto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    creado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    creadopor = table.Column<long>(type: "bigint", nullable: false),
                    descripcion_actividades = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    direccion = table.Column<int>(type: "int", nullable: false),
                    distribuidor_autorizadoid = table.Column<long>(type: "bigint", nullable: true),
                    factura = table.Column<bool>(type: "bit", nullable: false),
                    fecha_deposito = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    fecha_servicio = table.Column<DateTime>(type: "datetime2", nullable: false),
                    hora = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_cliente = table.Column<long>(type: "bigint", nullable: false),
                    id_distribuidor_autorizado = table.Column<int>(type: "int", nullable: false),
                    id_estatus_servicio = table.Column<int>(type: "int", nullable: false),
                    id_solicitado_por = table.Column<int>(type: "int", nullable: false),
                    id_solicitud_via = table.Column<int>(type: "int", nullable: false),
                    id_tecnico = table.Column<long>(type: "bigint", nullable: false),
                    id_tipo_servicio = table.Column<int>(type: "int", nullable: false),
                    no_operacion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    nombre_tarjetahabiente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    notarjeta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    terminos_condiciones = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Servicio", x => x.id);
                    table.ForeignKey(
                        name: "FK_Servicio_Cat_Materiales_Cat_Materialesid",
                        column: x => x.Cat_Materialesid,
                        principalTable: "Cat_Materiales",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Servicio_Clientes_clienteid",
                        column: x => x.clienteid,
                        principalTable: "Clientes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Servicio_Cat_distribuidor_autorizado_distribuidor_autorizadoid",
                        column: x => x.distribuidor_autorizadoid,
                        principalTable: "Cat_distribuidor_autorizado",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Estatus",
                        column: x => x.id_estatus_servicio,
                        principalTable: "Cat_estatus_servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Solicitadopor_Servicio",
                        column: x => x.id_solicitado_por,
                        principalTable: "Cat_solicitado_por",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Solicitadovia_Servicio",
                        column: x => x.id_solicitud_via,
                        principalTable: "Cat_solicitud_via",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Tecnico",
                        column: x => x.id_tecnico,
                        principalTable: "Tecnicos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_TipoServicio_Servicio",
                        column: x => x.id_tipo_servicio,
                        principalTable: "Cat_tipo_servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Rel_servicio_producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_servicio = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rel_servicio_producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Producto",
                        column: x => x.id_servicio,
                        principalTable: "Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Rel_servicio_Refaccion",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_servicio = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rel_servicio_Refaccion", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Refaccion",
                        column: x => x.id_servicio,
                        principalTable: "Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_id_servicio",
                table: "Rel_servicio_producto",
                column: "id_servicio");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_servicio",
                table: "Rel_servicio_Refaccion",
                column: "id_servicio");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_Cat_Materialesid",
                table: "Servicio",
                column: "Cat_Materialesid");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_clienteid",
                table: "Servicio",
                column: "clienteid");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_distribuidor_autorizadoid",
                table: "Servicio",
                column: "distribuidor_autorizadoid");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_estatus_servicio",
                table: "Servicio",
                column: "id_estatus_servicio");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_solicitado_por",
                table: "Servicio",
                column: "id_solicitado_por");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_solicitud_via",
                table: "Servicio",
                column: "id_solicitud_via");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_tecnico",
                table: "Servicio",
                column: "id_tecnico");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_tipo_servicio",
                table: "Servicio",
                column: "id_tipo_servicio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Rel_servicio_producto");

            migrationBuilder.DropTable(
                name: "Rel_servicio_Refaccion");

            migrationBuilder.DropTable(
                name: "Servicio");

            migrationBuilder.DropTable(
                name: "Cat_distribuidor_autorizado");

            migrationBuilder.DropTable(
                name: "Cat_estatus_servicio");

            migrationBuilder.DropTable(
                name: "Cat_solicitado_por");

            migrationBuilder.DropTable(
                name: "Cat_solicitud_via");

            migrationBuilder.DropTable(
                name: "Cat_tipo_servicio");
        }
    }
}
