﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class rel_tipo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "horas_tecnicos",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "id_tipo_servicio",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "no_tecnicos",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "precio_hora_tecnico",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "precio_visita",
                table: "Cat_Categoria_Producto");

            migrationBuilder.CreateTable(
                name: "Rel_Categoria_Producto_Tipo_Producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    horas_tecnicos = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_categoria = table.Column<int>(type: "int", nullable: false),
                    id_tipo_servicio = table.Column<int>(type: "int", nullable: false),
                    no_tecnicos = table.Column<int>(type: "int", nullable: false),
                    precio_hora_tecnico = table.Column<int>(type: "int", nullable: true),
                    precio_visita = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rel_Categoria_Producto_Tipo_Producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Categoria_Producto_Rel",
                        column: x => x.id_categoria,
                        principalTable: "Cat_Categoria_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Categoria_Producto_Rel_Tipo_Servicio",
                        column: x => x.id_tipo_servicio,
                        principalTable: "Cat_tipo_servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Rel_Categoria_Producto_Tipo_Producto_id_categoria",
                table: "Rel_Categoria_Producto_Tipo_Producto",
                column: "id_categoria");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_Categoria_Producto_Tipo_Producto_id_tipo_servicio",
                table: "Rel_Categoria_Producto_Tipo_Producto",
                column: "id_tipo_servicio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Rel_Categoria_Producto_Tipo_Producto");

            migrationBuilder.AddColumn<string>(
                name: "horas_tecnicos",
                table: "Cat_Categoria_Producto",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_tipo_servicio",
                table: "Cat_Categoria_Producto",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "no_tecnicos",
                table: "Cat_Categoria_Producto",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "precio_hora_tecnico",
                table: "Cat_Categoria_Producto",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "precio_visita",
                table: "Cat_Categoria_Producto",
                nullable: true);
        }
    }
}
