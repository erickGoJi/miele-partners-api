﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class delete_categoria : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Servicio_Categoria_servivio",
                table: "Servicio");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_id_categoria_servicio",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "creadopor",
                table: "Cotizaciones");

            migrationBuilder.AddColumn<int>(
                name: "Cat_Categoria_Servicioid",
                table: "Servicio",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_Cat_Categoria_Servicioid",
                table: "Servicio",
                column: "Cat_Categoria_Servicioid");

            migrationBuilder.AddForeignKey(
                name: "FK_Servicio_Cat_Categoria_Servicio_Cat_Categoria_Servicioid",
                table: "Servicio",
                column: "Cat_Categoria_Servicioid",
                principalTable: "Cat_Categoria_Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Servicio_Cat_Categoria_Servicio_Cat_Categoria_Servicioid",
                table: "Servicio");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_Cat_Categoria_Servicioid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "Cat_Categoria_Servicioid",
                table: "Servicio");

            migrationBuilder.AddColumn<int>(
                name: "creadopor",
                table: "Cotizaciones",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_categoria_servicio",
                table: "Servicio",
                column: "id_categoria_servicio");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Servicio_Categoria_servivio",
                table: "Servicio",
                column: "id_categoria_servicio",
                principalTable: "Cat_Categoria_Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
