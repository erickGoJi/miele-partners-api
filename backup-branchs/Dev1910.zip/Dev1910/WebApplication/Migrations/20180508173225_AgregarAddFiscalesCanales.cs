﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarAddFiscalesCanales : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "NumInt",
                table: "Cat_Direccion",
                newName: "numInt");

            migrationBuilder.RenameColumn(
                name: "NumExt",
                table: "Cat_Direccion",
                newName: "numExt");

            migrationBuilder.CreateTable(
                name: "DatosFiscales_Canales",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Ext_fact = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Int_fact = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    calle_numero = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    colonia = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_canal = table.Column<int>(type: "int", nullable: false),
                    id_estado = table.Column<int>(type: "int", nullable: false),
                    id_municipio = table.Column<int>(type: "int", nullable: false),
                    nombre_fact = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    razon_social = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    rfc = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    telefono_fact = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DatosFiscales_Canales", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DatosFiscales_Canales");

            migrationBuilder.RenameColumn(
                name: "numInt",
                table: "Cat_Direccion",
                newName: "NumInt");

            migrationBuilder.RenameColumn(
                name: "numExt",
                table: "Cat_Direccion",
                newName: "NumExt");
        }
    }
}
