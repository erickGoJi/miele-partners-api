﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class update_productos_4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_Categoria_Producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Categoria_Producto", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Linea_Producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_categoriaid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Linea_Producto", x => x.id);
                    table.ForeignKey(
                        name: "FK_Cat_Linea_Producto_Cat_Categoria_Producto_id_categoriaid",
                        column: x => x.id_categoriaid,
                        principalTable: "Cat_Categoria_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Cat_SubLinea_Producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_lineaid = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_SubLinea_Producto", x => x.id);
                    table.ForeignKey(
                        name: "FK_Cat_SubLinea_Producto_Cat_Linea_Producto_id_lineaid",
                        column: x => x.id_lineaid,
                        principalTable: "Cat_Linea_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Productos",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actualizado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    actualizadopor = table.Column<long>(type: "bigint", nullable: false),
                    atributus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    creado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    creadopor = table.Column<long>(type: "bigint", nullable: false),
                    descripcion_corta = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    descripcion_larga = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    ficha_tecnica = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_categoria = table.Column<int>(type: "int", nullable: false),
                    id_linea = table.Column<int>(type: "int", nullable: false),
                    id_sublinea = table.Column<int>(type: "int", nullable: false),
                    modelo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    precio_con_iva = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    precio_sin_iva = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    sku = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Productos", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Categoria_Producto",
                        column: x => x.id_categoria,
                        principalTable: "Cat_Categoria_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Linea_Producto",
                        column: x => x.id_linea,
                        principalTable: "Cat_Linea_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Sublinea_Producto",
                        column: x => x.id_sublinea,
                        principalTable: "Cat_SubLinea_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Imagenes_Producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_producto = table.Column<int>(type: "int", nullable: false),
                    url = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Imagenes_Producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Imagen_Producto",
                        column: x => x.id_producto,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Sugeridos_Producto",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_producto = table.Column<int>(type: "int", nullable: false),
                    sku_sugerido = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Sugeridos_Producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Sugeridos_Producto",
                        column: x => x.id_producto,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Imagenes_Producto_id_producto",
                table: "Cat_Imagenes_Producto",
                column: "id_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Linea_Producto_id_categoriaid",
                table: "Cat_Linea_Producto",
                column: "id_categoriaid");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Productos_id_categoria",
                table: "Cat_Productos",
                column: "id_categoria");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Productos_id_linea",
                table: "Cat_Productos",
                column: "id_linea");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Productos_id_sublinea",
                table: "Cat_Productos",
                column: "id_sublinea");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_SubLinea_Producto_id_lineaid",
                table: "Cat_SubLinea_Producto",
                column: "id_lineaid");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Sugeridos_Producto_id_producto",
                table: "Cat_Sugeridos_Producto",
                column: "id_producto");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cat_Imagenes_Producto");

            migrationBuilder.DropTable(
                name: "Cat_Sugeridos_Producto");

            migrationBuilder.DropTable(
                name: "Cat_Productos");

            migrationBuilder.DropTable(
                name: "Cat_SubLinea_Producto");

            migrationBuilder.DropTable(
                name: "Cat_Linea_Producto");

            migrationBuilder.DropTable(
                name: "Cat_Categoria_Producto");
        }
    }
}
