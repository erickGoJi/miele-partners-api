﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class checklist_visita_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Ckl_Pregunta_Respuesta",
                table: "Check_List_Respuestas");

            migrationBuilder.DropIndex(
                name: "IX_Check_List_Respuestas_id_pregunta",
                table: "Check_List_Respuestas");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Check_List_Respuestas_id_pregunta",
                table: "Check_List_Respuestas",
                column: "id_pregunta");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Ckl_Pregunta_Respuesta",
                table: "Check_List_Respuestas",
                column: "id_pregunta",
                principalTable: "Check_List_Preguntas",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
