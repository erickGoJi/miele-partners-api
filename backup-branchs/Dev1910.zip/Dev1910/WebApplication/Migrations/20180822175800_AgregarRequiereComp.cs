﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarRequiereComp : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_cuenta",
                table: "Cat_Formas_Pago");

            migrationBuilder.AddColumn<bool>(
                name: "comprobantes_obligatorios",
                table: "Cat_Formas_Pago",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "comprobantes_obligatorios",
                table: "Cat_Formas_Pago");

            migrationBuilder.AddColumn<int>(
                name: "id_cuenta",
                table: "Cat_Formas_Pago",
                nullable: false,
                defaultValue: 0);
        }
    }
}
