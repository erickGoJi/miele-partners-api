﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios_7 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "cat_direccionid",
                table: "Servicio",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_direccion",
                table: "Servicio",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Cat_Direccion",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    calle_numero = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    colonia = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_cliente = table.Column<long>(type: "bigint", nullable: false),
                    id_estado = table.Column<int>(type: "int", nullable: false),
                    id_municipio = table.Column<int>(type: "int", nullable: false),
                    telefono = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Direccion", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Direccion_Cliente",
                        column: x => x.id_cliente,
                        principalTable: "Clientes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_cat_direccionid",
                table: "Servicio",
                column: "cat_direccionid");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Direccion_id_cliente",
                table: "Cat_Direccion",
                column: "id_cliente");

            migrationBuilder.AddForeignKey(
                name: "FK_Servicio_Cat_Direccion_cat_direccionid",
                table: "Servicio",
                column: "cat_direccionid",
                principalTable: "Cat_Direccion",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Servicio_Cat_Direccion_cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropTable(
                name: "Cat_Direccion");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "id_direccion",
                table: "Servicio");
        }
    }
}
