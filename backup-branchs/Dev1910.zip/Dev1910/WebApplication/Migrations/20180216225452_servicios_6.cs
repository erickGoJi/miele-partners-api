﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios_6 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Servicio_Cat_Direccion_cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropTable(
                name: "Cat_Direccion");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "cat_direccionid",
                table: "Servicio");

            migrationBuilder.DropColumn(
                name: "id_direccion",
                table: "Servicio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "cat_direccionid",
                table: "Servicio",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_direccion",
                table: "Servicio",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Cat_Direccion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    calle_numero = table.Column<string>(nullable: true),
                    colonia = table.Column<string>(nullable: true),
                    cp = table.Column<string>(nullable: true),
                    estatus = table.Column<bool>(nullable: false),
                    id_cliente = table.Column<long>(nullable: false),
                    id_estadoid = table.Column<int>(nullable: true),
                    id_municipioid = table.Column<int>(nullable: true),
                    telefono = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Direccion", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Direccion_Cliente",
                        column: x => x.id_cliente,
                        principalTable: "Clientes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Cat_Direccion_Cat_Estado_id_estadoid",
                        column: x => x.id_estadoid,
                        principalTable: "Cat_Estado",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Cat_Direccion_Cat_Municipio_id_municipioid",
                        column: x => x.id_municipioid,
                        principalTable: "Cat_Municipio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_cat_direccionid",
                table: "Servicio",
                column: "cat_direccionid");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Direccion_id_cliente",
                table: "Cat_Direccion",
                column: "id_cliente");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Direccion_id_estadoid",
                table: "Cat_Direccion",
                column: "id_estadoid");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Direccion_id_municipioid",
                table: "Cat_Direccion",
                column: "id_municipioid");

            migrationBuilder.AddForeignKey(
                name: "FK_Servicio_Cat_Direccion_cat_direccionid",
                table: "Servicio",
                column: "cat_direccionid",
                principalTable: "Cat_Direccion",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
