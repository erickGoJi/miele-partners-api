﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarPermisosFlujo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Permisos_Cotizacion");

            migrationBuilder.CreateTable(
                name: "Permisos_Flujo_Cotizacion",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_Canal = table.Column<long>(type: "bigint", nullable: false),
                    id_estatus_cotizacion = table.Column<int>(type: "int", nullable: false),
                    id_rol = table.Column<long>(type: "bigint", nullable: false),
                    id_tabla = table.Column<int>(type: "int", nullable: false),
                    inhabilitado = table.Column<bool>(type: "bit", nullable: false),
                    permiso = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    visible = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Permisos_Flujo_Cotizacion", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Permisos_Flujo_Cotizacion");

            migrationBuilder.CreateTable(
                name: "Permisos_Cotizacion",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(nullable: true),
                    id_Canal = table.Column<long>(nullable: false),
                    id_estatus_cotizacion = table.Column<int>(nullable: false),
                    id_rol = table.Column<long>(nullable: false),
                    id_tabla = table.Column<int>(nullable: false),
                    inhabilitado = table.Column<bool>(nullable: false),
                    permiso = table.Column<string>(nullable: true),
                    visible = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Permisos_Cotizacion", x => x.id);
                });
        }
    }
}
