﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "id_producto",
                table: "Rel_servicio_Refaccion",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "productosid",
                table: "Rel_servicio_Refaccion",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_producto",
                table: "Rel_servicio_producto",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "productosid",
                table: "Rel_servicio_producto",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_productosid",
                table: "Rel_servicio_Refaccion",
                column: "productosid");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_producto_productosid",
                table: "Rel_servicio_producto",
                column: "productosid");

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_producto_Cat_Productos_productosid",
                table: "Rel_servicio_producto",
                column: "productosid",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Productos_productosid",
                table: "Rel_servicio_Refaccion",
                column: "productosid",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_producto_Cat_Productos_productosid",
                table: "Rel_servicio_producto");

            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Productos_productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_producto_productosid",
                table: "Rel_servicio_producto");

            migrationBuilder.DropColumn(
                name: "id_producto",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "id_producto",
                table: "Rel_servicio_producto");

            migrationBuilder.DropColumn(
                name: "productosid",
                table: "Rel_servicio_producto");
        }
    }
}
