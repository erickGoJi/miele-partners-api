﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class TroubleShooting : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_Productos_Estatus_Troubleshooting",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_troubleshooting = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Productos_Estatus_Troubleshooting", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Productos_Preguntas_Troubleshooting",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actualizado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    actualizadopor = table.Column<long>(type: "bigint", nullable: false),
                    creado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    creadopor = table.Column<long>(type: "bigint", nullable: false),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_producto = table.Column<int>(type: "int", nullable: false),
                    pregunta = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Productos_Preguntas_Troubleshooting", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_cat_productos_preguntas_troubleshooting",
                        column: x => x.id_producto,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Servicio_Troubleshooting",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_estatus_troubleshooting = table.Column<int>(type: "int", nullable: false),
                    id_servicio = table.Column<long>(type: "bigint", nullable: false),
                    observciones = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Servicio_Troubleshooting", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Troubleshooting",
                        column: x => x.id_estatus_troubleshooting,
                        principalTable: "Cat_Productos_Estatus_Troubleshooting",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_Troubleshooting_Servivo",
                        column: x => x.id_servicio,
                        principalTable: "Servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Productos_Respuestas_Troubleshooting",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actualizado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    actualizadopor = table.Column<long>(type: "bigint", nullable: false),
                    creado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    creadopor = table.Column<long>(type: "bigint", nullable: false),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    falla = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_troubleshooting = table.Column<int>(type: "int", nullable: false),
                    solucion = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Productos_Respuestas_Troubleshooting", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Cat_Productos_Respuestas_Troubleshooting",
                        column: x => x.id_troubleshooting,
                        principalTable: "Cat_Productos_Preguntas_Troubleshooting",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Productos_Preguntas_Troubleshooting_id_producto",
                table: "Cat_Productos_Preguntas_Troubleshooting",
                column: "id_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Productos_Respuestas_Troubleshooting_id_troubleshooting",
                table: "Cat_Productos_Respuestas_Troubleshooting",
                column: "id_troubleshooting");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_Troubleshooting_id_estatus_troubleshooting",
                table: "Servicio_Troubleshooting",
                column: "id_estatus_troubleshooting");

            migrationBuilder.CreateIndex(
                name: "IX_Servicio_Troubleshooting_id_servicio",
                table: "Servicio_Troubleshooting",
                column: "id_servicio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cat_Productos_Respuestas_Troubleshooting");

            migrationBuilder.DropTable(
                name: "Servicio_Troubleshooting");

            migrationBuilder.DropTable(
                name: "Cat_Productos_Preguntas_Troubleshooting");

            migrationBuilder.DropTable(
                name: "Cat_Productos_Estatus_Troubleshooting");
        }
    }
}
