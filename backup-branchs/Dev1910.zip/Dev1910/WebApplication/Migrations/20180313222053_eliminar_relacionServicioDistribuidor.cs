﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class eliminar_relacionServicioDistribuidor : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Servicio_Distribuidor_Autorizado",
                table: "Servicio");

            migrationBuilder.DropIndex(
                name: "IX_Servicio_id_distribuidor_autorizado",
                table: "Servicio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Servicio_id_distribuidor_autorizado",
                table: "Servicio",
                column: "id_distribuidor_autorizado");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Servicio_Distribuidor_Autorizado",
                table: "Servicio",
                column: "id_distribuidor_autorizado",
                principalTable: "Cat_distribuidor_autorizado",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
