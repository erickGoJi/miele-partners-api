﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class log_refacciones : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Log_refacciones",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    almacen_entrada = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    almacen_salida = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cantidad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_refaccion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    id_usuario = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Log_refacciones", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Log_refacciones");
        }
    }
}
