﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class producto_respuesta : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Check_list_Visita",
                table: "Check_List_Respuestas");

            migrationBuilder.DropIndex(
                name: "IX_Check_List_Respuestas_id_vista",
                table: "Check_List_Respuestas");

            migrationBuilder.DropColumn(
                name: "id_pregunta",
                table: "Check_List_Respuestas");

            migrationBuilder.DropColumn(
                name: "id_producto",
                table: "Check_List_Respuestas");

            migrationBuilder.DropColumn(
                name: "id_vista",
                table: "Check_List_Respuestas");

            migrationBuilder.AddColumn<int>(
                name: "id_producto_check_list_respuestas",
                table: "Check_List_Respuestas",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Producto_Check_List_Respuestas",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<int>(type: "int", nullable: false),
                    id_pregunta = table.Column<int>(type: "int", nullable: false),
                    id_producto = table.Column<long>(type: "bigint", nullable: false),
                    id_vista = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Producto_Check_List_Respuestas", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Producto_Check_List_Respuestas",
                        column: x => x.id_vista,
                        principalTable: "Visita",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Check_List_Respuestas_id_producto_check_list_respuestas",
                table: "Check_List_Respuestas",
                column: "id_producto_check_list_respuestas");

            migrationBuilder.CreateIndex(
                name: "IX_Producto_Check_List_Respuestas_id_vista",
                table: "Producto_Check_List_Respuestas",
                column: "id_vista");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Check_List_Respuestas",
                table: "Check_List_Respuestas",
                column: "id_producto_check_list_respuestas",
                principalTable: "Producto_Check_List_Respuestas",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Check_List_Respuestas",
                table: "Check_List_Respuestas");

            migrationBuilder.DropTable(
                name: "Producto_Check_List_Respuestas");

            migrationBuilder.DropIndex(
                name: "IX_Check_List_Respuestas_id_producto_check_list_respuestas",
                table: "Check_List_Respuestas");

            migrationBuilder.DropColumn(
                name: "id_producto_check_list_respuestas",
                table: "Check_List_Respuestas");

            migrationBuilder.AddColumn<int>(
                name: "id_pregunta",
                table: "Check_List_Respuestas",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<long>(
                name: "id_producto",
                table: "Check_List_Respuestas",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "id_vista",
                table: "Check_List_Respuestas",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "IX_Check_List_Respuestas_id_vista",
                table: "Check_List_Respuestas",
                column: "id_vista");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Check_list_Visita",
                table: "Check_List_Respuestas",
                column: "id_vista",
                principalTable: "Visita",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
