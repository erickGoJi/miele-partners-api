﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class edit_key_beneficio_msi : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_beneficio_msi_promocion_promocionid",
                table: "beneficio_msi");

            migrationBuilder.DropIndex(
                name: "IX_beneficio_msi_promocionid",
                table: "beneficio_msi");

            migrationBuilder.DropColumn(
                name: "promocionid",
                table: "beneficio_msi");

            migrationBuilder.CreateIndex(
                name: "IX_beneficio_msi_id_promocion",
                table: "beneficio_msi",
                column: "id_promocion");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_beneficiomsi_promo52",
                table: "beneficio_msi",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_beneficiomsi_promo52",
                table: "beneficio_msi");

            migrationBuilder.DropIndex(
                name: "IX_beneficio_msi_id_promocion",
                table: "beneficio_msi");

            migrationBuilder.AddColumn<int>(
                name: "promocionid",
                table: "beneficio_msi",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_beneficio_msi_promocionid",
                table: "beneficio_msi",
                column: "promocionid");

            migrationBuilder.AddForeignKey(
                name: "FK_beneficio_msi_promocion_promocionid",
                table: "beneficio_msi",
                column: "promocionid",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
