﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class CorrecionesCarrito : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Id_cotizacion",
                table: "Productos_Carrito");

            migrationBuilder.DropColumn(
                name: "fecha_Comprado",
                table: "Productos_Carrito");

            migrationBuilder.DropColumn(
                name: "fecha_vaciado",
                table: "Productos_Carrito");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Id_cotizacion",
                table: "Productos_Carrito",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "fecha_Comprado",
                table: "Productos_Carrito",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "fecha_vaciado",
                table: "Productos_Carrito",
                nullable: true);
        }
    }
}
