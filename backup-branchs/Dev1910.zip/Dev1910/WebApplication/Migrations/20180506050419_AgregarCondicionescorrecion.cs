﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarCondicionescorrecion : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_cotiacion",
                table: "CondicionesComerciales_Cuenta");

            migrationBuilder.AddColumn<int>(
                name: "id_condicion",
                table: "CondicionesComerciales_Cuenta",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_condicion",
                table: "CondicionesComerciales_Cuenta");

            migrationBuilder.AddColumn<int>(
                name: "id_cotiacion",
                table: "CondicionesComerciales_Cuenta",
                nullable: false,
                defaultValue: 0);
        }
    }
}
