﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class add_tablas_promocion5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_afectacion_cc_promocion2",
                table: "afectacion_cc");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_beneficiodesc_promocion2",
                table: "beneficio_desc");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_beneficioproductos_promocion2",
                table: "beneficio_productos");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_beneficiospromocion_promocion2",
                table: "beneficios_promocion");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_entidadesexcluidas_promocion2",
                table: "entidades_excluidas");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_entidadesparticipantes_promocion2",
                table: "entidades_participantes");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_productoscondicion_promocion2",
                table: "productos_condicion");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_promocion_condicion2",
                table: "promocion");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_promocion_herencia2",
                table: "promocion");

            migrationBuilder.AddColumn<bool>(
                name: "beneficio_obligatorio",
                table: "promocion",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "incluir_desc_adic",
                table: "promocion",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_9afectacion_cc_promocion2",
                table: "afectacion_cc",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_7beneficiodesc_promocion2",
                table: "beneficio_desc",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_8beneficioproductos_promocion2",
                table: "beneficio_productos",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_6beneficiospromocion_promocion2",
                table: "beneficios_promocion",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_4entidadesexcluidas_promocion2",
                table: "entidades_excluidas",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_3entidadesparticipantes_promocion2",
                table: "entidades_participantes",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_5productoscondicion_promocion2",
                table: "productos_condicion",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_2promocion_condicion2",
                table: "promocion",
                column: "id_cat_tipo_condicion",
                principalTable: "cat_tipo_condicion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_1promocion_herencia2",
                table: "promocion",
                column: "id_tipos_herencia_promo",
                principalTable: "cat_tipos_herencia",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_9afectacion_cc_promocion2",
                table: "afectacion_cc");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_7beneficiodesc_promocion2",
                table: "beneficio_desc");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_8beneficioproductos_promocion2",
                table: "beneficio_productos");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_6beneficiospromocion_promocion2",
                table: "beneficios_promocion");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_4entidadesexcluidas_promocion2",
                table: "entidades_excluidas");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_3entidadesparticipantes_promocion2",
                table: "entidades_participantes");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_5productoscondicion_promocion2",
                table: "productos_condicion");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_2promocion_condicion2",
                table: "promocion");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_1promocion_herencia2",
                table: "promocion");

            migrationBuilder.DropColumn(
                name: "beneficio_obligatorio",
                table: "promocion");

            migrationBuilder.DropColumn(
                name: "incluir_desc_adic",
                table: "promocion");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_afectacion_cc_promocion2",
                table: "afectacion_cc",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_beneficiodesc_promocion2",
                table: "beneficio_desc",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_beneficioproductos_promocion2",
                table: "beneficio_productos",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_beneficiospromocion_promocion2",
                table: "beneficios_promocion",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_entidadesexcluidas_promocion2",
                table: "entidades_excluidas",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_entidadesparticipantes_promocion2",
                table: "entidades_participantes",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_productoscondicion_promocion2",
                table: "productos_condicion",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_promocion_condicion2",
                table: "promocion",
                column: "id_cat_tipo_condicion",
                principalTable: "cat_tipo_condicion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_promocion_herencia2",
                table: "promocion",
                column: "id_tipos_herencia_promo",
                principalTable: "cat_tipos_herencia",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
