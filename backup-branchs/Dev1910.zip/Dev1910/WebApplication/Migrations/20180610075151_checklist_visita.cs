﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class checklist_visita : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_visita",
                table: "Check_List_Respuestas");

            migrationBuilder.AddColumn<long>(
                name: "id_vista",
                table: "Check_List_Respuestas",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "IX_Check_List_Respuestas_id_vista",
                table: "Check_List_Respuestas",
                column: "id_vista");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Check_list_Visita",
                table: "Check_List_Respuestas",
                column: "id_vista",
                principalTable: "Visita",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Check_list_Visita",
                table: "Check_List_Respuestas");

            migrationBuilder.DropIndex(
                name: "IX_Check_List_Respuestas_id_vista",
                table: "Check_List_Respuestas");

            migrationBuilder.DropColumn(
                name: "id_vista",
                table: "Check_List_Respuestas");

            migrationBuilder.AddColumn<int>(
                name: "id_visita",
                table: "Check_List_Respuestas",
                nullable: false,
                defaultValue: 0);
        }
    }
}
