﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class sacar_tecnico_visita : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Tecnico_Visita",
                table: "Visita");

            migrationBuilder.DropIndex(
                name: "IX_Visita_id_tecnico",
                table: "Visita");

            migrationBuilder.DropColumn(
                name: "id_tecnico",
                table: "Visita");

            migrationBuilder.AddColumn<long>(
                name: "Tecnicosid",
                table: "Visita",
                type: "bigint",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "rel_tecnico_visita",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_tecnico = table.Column<long>(type: "bigint", nullable: false),
                    id_vista = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_rel_tecnico_visita", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Tecnico_Visita",
                        column: x => x.id_tecnico,
                        principalTable: "Tecnicos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Visita_Tecnico",
                        column: x => x.id_vista,
                        principalTable: "Visita",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Visita_Tecnicosid",
                table: "Visita",
                column: "Tecnicosid");

            migrationBuilder.CreateIndex(
                name: "IX_rel_tecnico_visita_id_tecnico",
                table: "rel_tecnico_visita",
                column: "id_tecnico");

            migrationBuilder.CreateIndex(
                name: "IX_rel_tecnico_visita_id_vista",
                table: "rel_tecnico_visita",
                column: "id_vista");

            migrationBuilder.AddForeignKey(
                name: "FK_Visita_Tecnicos_Tecnicosid",
                table: "Visita",
                column: "Tecnicosid",
                principalTable: "Tecnicos",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Visita_Tecnicos_Tecnicosid",
                table: "Visita");

            migrationBuilder.DropTable(
                name: "rel_tecnico_visita");

            migrationBuilder.DropIndex(
                name: "IX_Visita_Tecnicosid",
                table: "Visita");

            migrationBuilder.DropColumn(
                name: "Tecnicosid",
                table: "Visita");

            migrationBuilder.AddColumn<long>(
                name: "id_tecnico",
                table: "Visita",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "IX_Visita_id_tecnico",
                table: "Visita",
                column: "id_tecnico");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Tecnico_Visita",
                table: "Visita",
                column: "id_tecnico",
                principalTable: "Tecnicos",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
