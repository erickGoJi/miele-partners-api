﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class fechainicio : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "fecha_inicio_servicio",
                table: "Servicio");

            migrationBuilder.AddColumn<DateTime>(
                name: "fecha_inicio_visita",
                table: "Visita",
                type: "datetime2",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "fecha_inicio_visita",
                table: "Visita");

            migrationBuilder.AddColumn<DateTime>(
                name: "fecha_inicio_servicio",
                table: "Servicio",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }
    }
}
