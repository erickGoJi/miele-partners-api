﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class edit_entidades_obl1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_entidades_obligatorias_cat_tipo_entidades_cat_tipo_entidadesid",
                table: "entidades_obligatorias");

            migrationBuilder.DropIndex(
                name: "IX_entidades_obligatorias_cat_tipo_entidadesid",
                table: "entidades_obligatorias");

            migrationBuilder.DropColumn(
                name: "cat_tipo_entidadesid",
                table: "entidades_obligatorias");

            migrationBuilder.DropColumn(
                name: "id_producto",
                table: "entidades_obligatorias");

            migrationBuilder.DropColumn(
                name: "id_tipo_categoria",
                table: "entidades_obligatorias");

            migrationBuilder.AddColumn<int>(
                name: "id_entidad",
                table: "entidades_obligatorias",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "id_tipo_entidad",
                table: "entidades_obligatorias",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_entidades_obligatorias_id_tipo_entidad",
                table: "entidades_obligatorias",
                column: "id_tipo_entidad");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_entidades_obligatorias_cattipoentidades2",
                table: "entidades_obligatorias",
                column: "id_tipo_entidad",
                principalTable: "cat_tipo_entidades",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_entidades_obligatorias_cattipoentidades2",
                table: "entidades_obligatorias");

            migrationBuilder.DropIndex(
                name: "IX_entidades_obligatorias_id_tipo_entidad",
                table: "entidades_obligatorias");

            migrationBuilder.DropColumn(
                name: "id_entidad",
                table: "entidades_obligatorias");

            migrationBuilder.DropColumn(
                name: "id_tipo_entidad",
                table: "entidades_obligatorias");

            migrationBuilder.AddColumn<int>(
                name: "cat_tipo_entidadesid",
                table: "entidades_obligatorias",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_producto",
                table: "entidades_obligatorias",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "id_tipo_categoria",
                table: "entidades_obligatorias",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_entidades_obligatorias_cat_tipo_entidadesid",
                table: "entidades_obligatorias",
                column: "cat_tipo_entidadesid");

            migrationBuilder.AddForeignKey(
                name: "FK_entidades_obligatorias_cat_tipo_entidades_cat_tipo_entidadesid",
                table: "entidades_obligatorias",
                column: "cat_tipo_entidadesid",
                principalTable: "cat_tipo_entidades",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
