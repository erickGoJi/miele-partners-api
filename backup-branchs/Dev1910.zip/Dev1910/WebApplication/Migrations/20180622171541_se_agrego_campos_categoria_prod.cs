﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class se_agrego_campos_categoria_prod : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "horas_tecnicos",
                table: "Cat_Categoria_Producto",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_tipo_servicio",
                table: "Cat_Categoria_Producto",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "no_tecnicos",
                table: "Cat_Categoria_Producto",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "precio_hora_tecnico",
                table: "Cat_Categoria_Producto",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "precio_visita",
                table: "Cat_Categoria_Producto",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "horas_tecnicos",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "id_tipo_servicio",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "no_tecnicos",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "precio_hora_tecnico",
                table: "Cat_Categoria_Producto");

            migrationBuilder.DropColumn(
                name: "precio_visita",
                table: "Cat_Categoria_Producto");
        }
    }
}
