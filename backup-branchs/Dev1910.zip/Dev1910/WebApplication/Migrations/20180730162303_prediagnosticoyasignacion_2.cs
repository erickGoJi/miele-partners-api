﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class prediagnosticoyasignacion_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "si_acepto",
                table: "Prediagnostico_Refacciones");

            migrationBuilder.AddColumn<bool>(
                name: "si_acepto_tecnico_refaccion",
                table: "Visita",
                type: "bit",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "si_acepto_tecnico_refaccion",
                table: "Visita");

            migrationBuilder.AddColumn<bool>(
                name: "si_acepto",
                table: "Prediagnostico_Refacciones",
                nullable: true);
        }
    }
}
