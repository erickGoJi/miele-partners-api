﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_Actividad",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_actividad = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Actividad", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Area_Cobertura",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_cobertura = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Area_Cobertura", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Producto",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_producto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Producto", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Tecnicos_Tipo",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    desc_tipo = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Tecnicos_Tipo", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "RegistroItems",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsComplete = table.Column<bool>(type: "bit", nullable: false),
                    Materno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Paterno = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RegistroItems", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TokenItems",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Fecha = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Id_user = table.Column<long>(type: "bigint", nullable: false),
                    Token = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TokenItems", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    actualizado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    actualizadopor = table.Column<long>(type: "bigint", nullable: false),
                    avatar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    creado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    creadopor = table.Column<long>(type: "bigint", nullable: false),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    fecha_nacimiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    materno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    paterno = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    telefono = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    telefono_movil = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    username = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Tecnicos",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false),
                    actualizado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    actualizadopor = table.Column<long>(type: "bigint", nullable: false),
                    creado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    creadopor = table.Column<long>(type: "bigint", nullable: false),
                    id_tipo_tecnico = table.Column<int>(type: "int", nullable: false),
                    noalmacen = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tecnicos", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos",
                        column: x => x.id,
                        principalTable: "Users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Tipo",
                        column: x => x.id_tipo_tecnico,
                        principalTable: "Cat_Tecnicos_Tipo",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tecnicos_Actividad",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_actividad = table.Column<long>(type: "bigint", nullable: false),
                    id_user = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tecnicos_Actividad", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Actividad_Cat",
                        column: x => x.id_actividad,
                        principalTable: "Cat_Actividad",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Actividad",
                        column: x => x.id_user,
                        principalTable: "Tecnicos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tecnicos_Cobertura",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_cobertura = table.Column<long>(type: "bigint", nullable: false),
                    id_user = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tecnicos_Cobertura", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Cobertura_Cat",
                        column: x => x.id_cobertura,
                        principalTable: "Cat_Area_Cobertura",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Cobertura",
                        column: x => x.id_user,
                        principalTable: "Tecnicos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tecnicos_Producto",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_producto = table.Column<long>(type: "bigint", nullable: false),
                    id_user = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tecnicos_Producto", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Producto_Cat",
                        column: x => x.id_producto,
                        principalTable: "Cat_Producto",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "ForeignKey_Users_Tecnicos_Productos",
                        column: x => x.id_user,
                        principalTable: "Tecnicos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_id_tipo_tecnico",
                table: "Tecnicos",
                column: "id_tipo_tecnico");

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Actividad_id_actividad",
                table: "Tecnicos_Actividad",
                column: "id_actividad");

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Actividad_id_user",
                table: "Tecnicos_Actividad",
                column: "id_user");

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Cobertura_id_cobertura",
                table: "Tecnicos_Cobertura",
                column: "id_cobertura");

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Cobertura_id_user",
                table: "Tecnicos_Cobertura",
                column: "id_user");

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Producto_id_producto",
                table: "Tecnicos_Producto",
                column: "id_producto");

            migrationBuilder.CreateIndex(
                name: "IX_Tecnicos_Producto_id_user",
                table: "Tecnicos_Producto",
                column: "id_user");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RegistroItems");

            migrationBuilder.DropTable(
                name: "Tecnicos_Actividad");

            migrationBuilder.DropTable(
                name: "Tecnicos_Cobertura");

            migrationBuilder.DropTable(
                name: "Tecnicos_Producto");

            migrationBuilder.DropTable(
                name: "TokenItems");

            migrationBuilder.DropTable(
                name: "Cat_Actividad");

            migrationBuilder.DropTable(
                name: "Cat_Area_Cobertura");

            migrationBuilder.DropTable(
                name: "Cat_Producto");

            migrationBuilder.DropTable(
                name: "Tecnicos");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Cat_Tecnicos_Tipo");
        }
    }
}
