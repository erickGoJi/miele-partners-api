﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class delete_cliente_producto : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cliente_Productos");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cliente_Productos",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Cat_Estatus_CompraId = table.Column<long>(nullable: true),
                    Cat_Productosid = table.Column<int>(nullable: true),
                    FechaCompra = table.Column<DateTime>(nullable: false),
                    FinGarantia = table.Column<DateTime>(nullable: false),
                    Id_Cliente = table.Column<long>(nullable: false),
                    Id_EsatusCompra = table.Column<long>(nullable: false),
                    Id_Producto = table.Column<long>(nullable: false),
                    NoOrdenCompra = table.Column<string>(nullable: true),
                    NoPoliza = table.Column<string>(nullable: true),
                    actualizado = table.Column<DateTime>(nullable: false),
                    actualizadopor = table.Column<long>(nullable: false),
                    creado = table.Column<DateTime>(nullable: false),
                    creadopor = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cliente_Productos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Cliente_Productos_Cat_Estatus_Compra_Cat_Estatus_CompraId",
                        column: x => x.Cat_Estatus_CompraId,
                        principalTable: "Cat_Estatus_Compra",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Cliente_Productos_Cat_Productos_Cat_Productosid",
                        column: x => x.Cat_Productosid,
                        principalTable: "Cat_Productos",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "ForeignKey_Cliente_Producto",
                        column: x => x.Id_Cliente,
                        principalTable: "Clientes",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Cat_Estatus_CompraId",
                table: "Cliente_Productos",
                column: "Cat_Estatus_CompraId");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Cat_Productosid",
                table: "Cliente_Productos",
                column: "Cat_Productosid");

            migrationBuilder.CreateIndex(
                name: "IX_Cliente_Productos_Id_Cliente",
                table: "Cliente_Productos",
                column: "Id_Cliente");
        }
    }
}
