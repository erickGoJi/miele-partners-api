﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class delete_servicio_recacciones_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_Refaccion_Servicio_serviciosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_serviciosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "serviciosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_servicio",
                table: "Rel_servicio_Refaccion",
                column: "id_servicio");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_Rel_Servicio_Refaccion",
                table: "Rel_servicio_Refaccion",
                column: "id_servicio",
                principalTable: "Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_Rel_Servicio_Refaccion",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_id_servicio",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.AddColumn<long>(
                name: "serviciosid",
                table: "Rel_servicio_Refaccion",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_serviciosid",
                table: "Rel_servicio_Refaccion",
                column: "serviciosid");

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_Refaccion_Servicio_serviciosid",
                table: "Rel_servicio_Refaccion",
                column: "serviciosid",
                principalTable: "Servicio",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
