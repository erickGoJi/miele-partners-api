﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregaraceptoTerminos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "id_condpago",
                table: "Cotizaciones");

            migrationBuilder.DropColumn(
                name: "id_entrega_sol",
                table: "Cotizaciones");

            migrationBuilder.AddColumn<bool>(
                name: "acepto_terminos_condiciones",
                table: "Cotizaciones",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "id_user_entrega_sol",
                table: "Cotizaciones",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "usr_modifico",
                table: "Cotizaciones",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "acepto_terminos_condiciones",
                table: "Cotizaciones");

            migrationBuilder.DropColumn(
                name: "id_user_entrega_sol",
                table: "Cotizaciones");

            migrationBuilder.DropColumn(
                name: "usr_modifico",
                table: "Cotizaciones");

            migrationBuilder.AddColumn<int>(
                name: "id_condpago",
                table: "Cotizaciones",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "id_entrega_sol",
                table: "Cotizaciones",
                nullable: false,
                defaultValue: false);
        }
    }
}
