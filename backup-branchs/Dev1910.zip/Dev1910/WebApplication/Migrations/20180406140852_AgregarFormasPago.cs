﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class AgregarFormasPago : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Ext_fact",
                table: "DatosFiscales",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Int_fact",
                table: "DatosFiscales",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "nombre_fact",
                table: "DatosFiscales",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "telefono_fact",
                table: "DatosFiscales",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Cat_CondicionesPago",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CondicionPago = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_CondicionesPago", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Formas_Pago",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FormaPago = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Formas_Pago", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cat_CondicionesPago");

            migrationBuilder.DropTable(
                name: "Cat_Formas_Pago");

            migrationBuilder.DropColumn(
                name: "Ext_fact",
                table: "DatosFiscales");

            migrationBuilder.DropColumn(
                name: "Int_fact",
                table: "DatosFiscales");

            migrationBuilder.DropColumn(
                name: "nombre_fact",
                table: "DatosFiscales");

            migrationBuilder.DropColumn(
                name: "telefono_fact",
                table: "DatosFiscales");
        }
    }
}
