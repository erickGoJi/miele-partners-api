﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class fecha_direccion : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "actualizado",
                table: "Cat_Direccion",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<long>(
                name: "actualizadopor",
                table: "Cat_Direccion",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<DateTime>(
                name: "creado",
                table: "Cat_Direccion",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<long>(
                name: "creadopor",
                table: "Cat_Direccion",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "actualizado",
                table: "Cat_Direccion");

            migrationBuilder.DropColumn(
                name: "actualizadopor",
                table: "Cat_Direccion");

            migrationBuilder.DropColumn(
                name: "creado",
                table: "Cat_Direccion");

            migrationBuilder.DropColumn(
                name: "creadopor",
                table: "Cat_Direccion");
        }
    }
}
