﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class relaciones_TablasnuevasPromo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "entidades_obligatorias",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    cat_tipo_entidadesid = table.Column<int>(type: "int", nullable: true),
                    id_producto = table.Column<int>(type: "int", nullable: false),
                    id_promocion = table.Column<int>(type: "int", nullable: false),
                    id_tipo_categoria = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_entidades_obligatorias", x => x.id);
                    table.ForeignKey(
                        name: "FK_entidades_obligatorias_cat_tipo_entidades_cat_tipo_entidadesid",
                        column: x => x.cat_tipo_entidadesid,
                        principalTable: "cat_tipo_entidades",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "ForeignKey_4entidadesobli_promocion2",
                        column: x => x.id_promocion,
                        principalTable: "promocion",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "promociones_compatibles",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    id_promocion_1 = table.Column<int>(type: "int", nullable: false),
                    id_promocion_2 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_promociones_compatibles", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_productos_excluidos_id_promocion",
                table: "productos_excluidos",
                column: "id_promocion");

            migrationBuilder.CreateIndex(
                name: "IX_entidades_obligatorias_cat_tipo_entidadesid",
                table: "entidades_obligatorias",
                column: "cat_tipo_entidadesid");

            migrationBuilder.CreateIndex(
                name: "IX_entidades_obligatorias_id_promocion",
                table: "entidades_obligatorias",
                column: "id_promocion");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_5productos_excluidos_promocion2",
                table: "productos_excluidos",
                column: "id_promocion",
                principalTable: "promocion",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_5productos_excluidos_promocion2",
                table: "productos_excluidos");

            migrationBuilder.DropTable(
                name: "entidades_obligatorias");

            migrationBuilder.DropTable(
                name: "promociones_compatibles");

            migrationBuilder.DropIndex(
                name: "IX_productos_excluidos_id_promocion",
                table: "productos_excluidos");
        }
    }
}
