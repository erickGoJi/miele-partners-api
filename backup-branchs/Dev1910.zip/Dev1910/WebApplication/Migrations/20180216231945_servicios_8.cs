﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class servicios_8 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "ForeignKey_producto_Refaccion",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_id_producto",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "id_producto",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.AddColumn<int>(
                name: "Cat_Productosid",
                table: "Rel_servicio_Refaccion",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "id_material",
                table: "Rel_servicio_Refaccion",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_Cat_Productosid",
                table: "Rel_servicio_Refaccion",
                column: "Cat_Productosid");

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_material",
                table: "Rel_servicio_Refaccion",
                column: "id_material");

            migrationBuilder.AddForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Productos_Cat_Productosid",
                table: "Rel_servicio_Refaccion",
                column: "Cat_Productosid",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_producto_Refaccion",
                table: "Rel_servicio_Refaccion",
                column: "id_material",
                principalTable: "Cat_Materiales",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Rel_servicio_Refaccion_Cat_Productos_Cat_Productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropForeignKey(
                name: "ForeignKey_producto_Refaccion",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_Cat_Productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropIndex(
                name: "IX_Rel_servicio_Refaccion_id_material",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "Cat_Productosid",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.DropColumn(
                name: "id_material",
                table: "Rel_servicio_Refaccion");

            migrationBuilder.AddColumn<int>(
                name: "id_producto",
                table: "Rel_servicio_Refaccion",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Rel_servicio_Refaccion_id_producto",
                table: "Rel_servicio_Refaccion",
                column: "id_producto");

            migrationBuilder.AddForeignKey(
                name: "ForeignKey_producto_Refaccion",
                table: "Rel_servicio_Refaccion",
                column: "id_producto",
                principalTable: "Cat_Productos",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
