﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class delete_refacciones : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cat_Materiales");

            migrationBuilder.DropTable(
                name: "Cat_Lista_Precios");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cat_Lista_Precios",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(nullable: false),
                    grupo_precio = table.Column<string>(nullable: true),
                    precio_sin_iva = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Lista_Precios", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Cat_Materiales",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    descripcion = table.Column<string>(nullable: true),
                    estatus = table.Column<bool>(nullable: false),
                    grupo_precioid = table.Column<int>(nullable: true),
                    no_material = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cat_Materiales", x => x.id);
                    table.ForeignKey(
                        name: "FK_Cat_Materiales_Cat_Lista_Precios_grupo_precioid",
                        column: x => x.grupo_precioid,
                        principalTable: "Cat_Lista_Precios",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Cat_Materiales_grupo_precioid",
                table: "Cat_Materiales",
                column: "grupo_precioid");
        }
    }
}
