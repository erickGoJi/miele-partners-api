﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebApplication.Migrations
{
    public partial class subtiposervicio : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Sub_cat_tipo_servicio",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    estatus = table.Column<bool>(type: "bit", nullable: false),
                    id_tipo_servicio = table.Column<int>(type: "int", nullable: false),
                    sub_desc_tipo_servicio = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sub_cat_tipo_servicio", x => x.id);
                    table.ForeignKey(
                        name: "ForeignKey_Servicio_SubTipoServicio",
                        column: x => x.id_tipo_servicio,
                        principalTable: "Cat_tipo_servicio",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Sub_cat_tipo_servicio_id_tipo_servicio",
                table: "Sub_cat_tipo_servicio",
                column: "id_tipo_servicio");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Sub_cat_tipo_servicio");
        }
    }
}
