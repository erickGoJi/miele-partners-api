﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using WebApplication.Models;
using WebApplication.Repository;
using WebApplication.ViewModels;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using WebApplication.ViewModels.Catalogs.ProductSuperLinea;

namespace WebApplication.Controllers
{
    [Produces("application/json")]
    [Route("api/Productos")]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class ProductosController : Controller
    {
        private IConfiguration _config;
        private readonly MieleContext _context;
        private readonly IMapper _mapper;
        private readonly IProductoRepository _repo;

        private readonly IProductCategoriesRepository _repoProductCategories;
        private readonly IProductLinesRepository _repoProductLines;
        private readonly IProductSubLinesRepository _repoProductSubLines;

        public ProductosController(
            IConfiguration config,
            MieleContext context,
            IProductoRepository repo,
            IMapper mapper,
            IProductCategoriesRepository repoProductCategories,
            IProductLinesRepository repoProductLines,
            IProductSubLinesRepository repoProductSubLines
            )
        {
            _config = config;
            _context = context;
            _repo = repo;
            _mapper = mapper;
            _repoProductCategories = repoProductCategories;
            _repoProductLines = repoProductLines;
            _repoProductSubLines = repoProductSubLines;
        }

        // GET: api/Productos
        [HttpGet]
        public IActionResult GetAll()
        {
            var item = (from a in _context.Cat_Productos
                            //join b in _context.Cat_Categoria_Producto on a.id_categoria equals b.id
                        join c in _context.Cat_Linea_Producto on a.id_linea equals c.id
                        join d in _context.Cat_SubLinea_Producto on a.id_sublinea equals d.id
                        select new
                        {
                            id = a.id,
                            nombre = a.nombre,
                            categoria = c.descripcion,
                            a.id_linea,
                            linea = c.descripcion,
                            a.id_sublinea,
                            sublinea = d.descripcion,
                            descripcion_corta = a.descripcion_corta,
                            descripcion_larga = a.descripcion_larga,
                            ficha_tecnica = a.ficha_tecnica,
                            precio_sin_iva = a.precio_sin_iva,
                            precio_con_iva = a.precio_con_iva,
                            sku = a.sku,
                            tipo = a.tipo,
                            img_url = (from x in _context.Cat_Imagenes_Producto
                                       where x.id_producto == a.id
                                       select x)
                                         .Select(c => new Cat_Imagenes_Producto
                                         {
                                             id = c.id,
                                             id_producto = c.id_producto,
                                             url = c.url,
                                             estatus = c.estatus
                                         }).ToList()
                        }).ToList();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }


        // GET: api/Productos
        //[Route("GetAllProducts")]
        [HttpGet("GetAllProducts", Name = "GetAllProducts")]
        public IActionResult GetAllProducts()
        {
            var item = (from a in _context.Cat_Productos
                            //join b in _context.Cat_Categoria_Producto on a.id_categoria equals b.id
                        join c in _context.Cat_Linea_Producto on a.id_linea equals c.id
                        join d in _context.Cat_SubLinea_Producto on a.id_sublinea equals d.id
                        where d.id_linea_producto != 36 && d.id_linea_producto != 38
                        select new
                        {
                            id = a.id,
                            nombre = a.nombre,
                            categoria = c.descripcion,
                            a.id_linea,
                            linea = c.descripcion,
                            a.id_sublinea,
                            sublinea = d.descripcion,
                            descripcion_corta = a.descripcion_corta,
                            descripcion_larga = a.descripcion_larga,
                            ficha_tecnica = a.ficha_tecnica,
                            precio_sin_iva = a.precio_sin_iva,
                            precio_con_iva = a.precio_con_iva,
                            sku = a.sku,
                            tipo = a.tipo,
                            img_url = (from x in _context.Cat_Imagenes_Producto
                                       where x.id_producto == a.id
                                       select x)
                                         .Select(c => new Cat_Imagenes_Producto
                                         {
                                             id = c.id,
                                             id_producto = c.id_producto,
                                             url = c.url,
                                             estatus = c.estatus
                                         }).ToList()
                        }).ToList();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }

        // GET: api/Productos/5
        [HttpGet("{id}", Name = "GetProductos")]
        public IActionResult Get(int id)
        {
            try
            {
                ProductsDto dto = _mapper.Map<ProductsDto>(_repo.Get(id));
                dto.relacionados = (from a in _context.productos_relacionados
                                    where (a.id_producto == id) || (a.id_producto_2 == id)
                                    select new ProductsRelatedDto
                                    {
                                        id = a.id,
                                        id_producto = id,
                                        id_producto_2 = (a.id_producto == id ? a.id_producto_2 : a.id_producto),
                                    }).ToList();
                //var item = (from a  )
                //    _context.Cat_Productos.Where(p => p.id == id)
                //.Include(p => p.sublinea)
                //.Include(p => p.linea)
                //.Include(p => p.sublinea)
                //.Include(p => p.cat_imagenes_producto)
                //.FirstOrDefault();


                if (dto == null)
                {
                    return NotFound();
                }

                return Ok(dto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        [HttpDelete("Image/{prodId},{imgId}", Name = "DelImage_Producto")]
        public IActionResult DelImage_Producto(int prodId, int imgId)
        {
            try
            {
                var delImg = _context.Cat_Imagenes_Producto.First(a => a.id == imgId);
                if (delImg.id > 0)
                {
                    _context.Cat_Imagenes_Producto.Remove(delImg);
                    _context.SaveChanges();
                }
                List<ProductImagesDto> dto = _mapper.Map<List<ProductImagesDto>>(_context.Cat_Imagenes_Producto.Where(i => i.id_producto == prodId));
                return Ok(new { Success = true, dto });
            }
            catch (Exception ex)
            {
                return Ok(new { Success = false });
                throw;
            }
        }


        [HttpGet("GetModels/{id}", Name = "GetModels")]
        public IActionResult GetModelosxSublinea(int id)
        {
            //Recibe el id de un producto, busca la sublinea de este producto y devuelve la lista de productos de la sublinea
            try
            {
                ProductsDto dto = _mapper.Map<ProductsDto>(_repo.Get(id));
                ProductSubLineDto lineDto = _mapper.Map<ProductSubLineDto>(_repoProductSubLines.Get(Convert.ToInt32(dto.id_sublinea)));

                if (dto == null)
                {
                    return NotFound();
                }
                //List<ProductModelDto> modelDtoAnt = _mapper.Map<List<ProductModelDto>>(_context.Cat_Productos.Where(p => p.id_sublinea == dto.id_sublinea).ToList());

                List<ProductModelDto> modelDto = (from a in _context.Cat_Productos
                                                  join b in _context.Cat_SubLinea_Producto on a.id_sublinea equals b.id
                                                  where b.id_linea_producto == lineDto.id_linea_producto
                                                  select new ProductModelDto
                                                  {
                                                      id = a.id,
                                                      nombre = a.nombre,
                                                      modelo = a.modelo
                                                  }).ToList();
                if (modelDto == null)
                {
                    return NotFound();
                }

                return Ok(modelDto);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        // GET: api/Productos/5
        [HttpGet("GetRelated/{id}", Name = "GetRelatedProducts")]
        public IActionResult RelatedProducts(int id)
        {
            try
            {
                //var prods = (from rp in _context.productos_relacionados
                //            join p in _context.Cat_Productos on rp.id_producto_2 equals p.id
                //            where rp.id_producto == id
                //            select new {
                //                rp.id,
                //                rp.id_producto,
                //                id_prod_rel = rp.id_producto_2,
                //                p.nombre,
                //                p.sku,
                //                p.modelo,
                //                p.id_linea,
                //                p.id_sublinea
                //            });

                //var prods_2 = (from rp in _context.productos_relacionados
                //                join p in _context.Cat_Productos on rp.id_producto equals p.id
                //                where rp.id_producto_2 == id
                //                select new {
                //                    rp.id,
                //                    id_producto = rp.id_producto_2,
                //                    id_prod_rel = rp.id_producto,
                //                    p.nombre,
                //                    p.sku,
                //                    p.modelo,
                //                    p.id_linea,
                //                    p.id_sublinea
                //                });

                var prods_rel = (from a in _context.productos_relacionados
                                 where (a.id_producto == id) || (a.id_producto_2 == id)
                                 select new
                                 {
                                     id = a.id,
                                     id_prod_rel = (a.id_producto == id ? a.id_producto_2 : a.id_producto),
                                 }).ToList();



                if (prods_rel == null)
                {
                    return NotFound();
                }

                return Ok(prods_rel);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        // POST: api/Productos
        [HttpPost]
        public IActionResult Post([FromBody]Cat_Productos item)
        {
            var result = new Models.Response();

            try
            {
                if (item == null)
                {
                    return BadRequest();
                }
                else
                {
                    _context.Cat_Productos.Add(item);
                    _context.SaveChanges();
                    result = new Models.Response
                    {
                        response = "OK"
                    };
                }
            }
            catch (Exception ex)
            {
                result = new Models.Response
                {
                    response = ex.ToString()
                };
            }
            return new ObjectResult(result);
        }

        [HttpPost("Create")]
        public IActionResult Create([FromBody]ProductsUpdateDto createDto)
        {
            try
            {
                if (!_repoProductCategories.Exists(createDto.id_categoria))
                    return NotFound($"Product category with Id { createDto.id_categoria } Not Found");

                if (!_repoProductLines.Exists(createDto.id_linea))
                    return NotFound($"Product line with Id {createDto.id_linea} Not Found");

                if (!_repoProductSubLines.Exists(createDto.id_sublinea))
                    return NotFound($"Product sub line with Id {createDto.id_sublinea} Not Found");

                //var productLine = _mapper.Map<Cat_Linea_Producto>(productLinesDto);
                Cat_Productos product = _mapper.Map<Cat_Productos>(createDto);

                if(createDto.manejostockcheck == true)
                {
                    Stock_Inicial _stockinicial = new Stock_Inicial();
                    product.manejos_stock_check = createDto.manejostockcheck;
                    _stockinicial = product.stcInicial;
                    var _resultStockInicial = _context.Stock_Inicial.Update(_stockinicial);
                    var _resultadosConsulta = _resultStockInicial.Entity;
                    product.stcInicial = _resultadosConsulta;
                    product.stcInicialid = _resultadosConsulta.id;
                }
                //if (createDto.minimo_Carrito)
                //{

                //}
               
                //_stockinicial.stock_temp_actual = 0;
              
                product = _repo.Add(product);




                //var result = _repo.Add(product);


                //foreach (ProductsRelatedDto item in createDto.relacionados)
                //{
                //    item.id_producto = product.id;
                //    productos_relacionados pr = _mapper.Map<productos_relacionados>(item);
                //    _context.productos_relacionados.Add(pr);
                //}
                foreach (productos_relacionados item in createDto.relacionados)
                {
                    item.id_producto = product.id;
                    _context.productos_relacionados.Add(item);
                }
                _context.SaveChanges();
                return CreatedAtRoute("GetProductSubLines", new { product.id }, product);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        [HttpPost("Search")]
        public IActionResult Search([FromBody]ProductsSearchDto productsSearchDto)
        {
            try
            {
                var item = _repo.FindAllSearch(productsSearchDto);

                if (item == null)
                {
                    return NotFound();
                }

                return Ok(item);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        // PUT: api/Productos/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]ProductsUpdateDto productsUpdateDto)
        {
            try
            {
                if (!_repo.Exists(id))
                    return NotFound($"Product with Id { id } Not Found");

                if (!_repoProductCategories.Exists(productsUpdateDto.id_categoria))
                    return NotFound($"Product category with Id { productsUpdateDto.id_categoria } Not Found");

                if (!_repoProductLines.Exists(productsUpdateDto.id_linea))
                    return NotFound($"Product line with Id { productsUpdateDto.id_linea } Not Found");

                if (!_repoProductSubLines.Exists(productsUpdateDto.id_sublinea))
                    return NotFound($"Product sub line with Id { productsUpdateDto.id_sublinea } Not Found");


                //productsUpdateDto.cat_imagenes_producto
                //var result = _repo.Get(id);
                Cat_Productos product = _mapper.Map<Cat_Productos>(productsUpdateDto);
                product.id = id;
                var result = _repo.Update(product, id);
                //string res = GuardarRelacionados(productsUpdateDto.relacionados, id);
                List<productos_relacionados> nuevos = productsUpdateDto.relacionados.Where(r => r.id == 0).ToList();
                List<productos_relacionados> act = productsUpdateDto.relacionados.Where(r => r.id > 0).ToList();
                List<productos_relacionados> exis = _context.productos_relacionados.Where(p => p.id_producto == id || p.id_producto_2 == id).ToList();
                List<Cat_Imagenes_Producto> imgs = _context.Cat_Imagenes_Producto.Where(i => i.id_producto == id).ToList();
                foreach (ProductImagesDto item in productsUpdateDto.cat_imagenes_producto)
                {
                    if (!imgs.Exists(db => db.url == item.url))
                    {
                        _context.Cat_Imagenes_Producto.Add(new Cat_Imagenes_Producto { estatus = true, id_producto = id, url = item.url });
                    }
                }

                foreach (productos_relacionados item in exis)
                {
                    if (!act.Exists(c => c.id == item.id))
                    {
                        _context.productos_relacionados.Remove(item);
                    }
                }

                foreach (productos_relacionados item in nuevos)
                {
                    _context.productos_relacionados.Add(item);
                }
                _context.SaveChanges();
                //result.id_categoria = _repoProductCategories.Get(productLinesUpdateDto.id_categoria);
                //resul = productLinesUpdateDto.descripcion;
                //result.estatus = productLinesUpdateDto.estatus;
                //_repo.Update(result, id);

                return Ok(result);

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        //// DELETE: api/ApiWithActions/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}


        [HttpGet("download_xls")]
        public IActionResult DescargarPlantillaUsuarios()
        {
            IActionResult response = Unauthorized();
            try
            {
                var selRuta = _context.parametro_Archivos.FirstOrDefault(p => p.id == 1);
                return response = Ok(new { result = "Success", data = selRuta.funcion + "plantilla_precios_productos.xls" });
            }
            catch (Exception ex)
            {
                return response = Ok(new { result = "Error", detalles = ex.Message });
            }


        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("ProductoStockVerificaExistencia/{id}")]
        public IActionResult ProductoStockVerificaExistencia(int id)
        {
            IActionResult response = Unauthorized();
            try
            {
                //var _resultado= _context.Stock_Inicial
                var item = (from a in _context.Cat_Productos.Where(p => p.id == id)
                                //join b in _context.Cat_Categoria_Producto on a.id_categoria equals b.id
                            join c in _context.Cat_Linea_Producto on a.id_linea equals c.id
                            join d in _context.Cat_SubLinea_Producto on a.id_sublinea equals d.id
                            join e in _context.cat_SuperLineas on c.id_superlinea equals e.id
                            join f in _context.Stock_Inicial on a.stcInicial.id equals f.id
                            select new
                            {
                                stcInicialid = a.stcInicialid,
                                stock_inicial = f.stock_inicial == null ? 0 : f.stock_inicial,
                                stock_actual = f.stock_actual == null ? 0 : f.stock_actual,
                                stock_desplazado = f.stock_desplazado == null ? 0 : f.stock_desplazado,
                                ///stock_temp_actual = f.stock_temp_actual == null ? 0 : f.stock_temp_actual

                            }).FirstOrDefault();

                if (item == null)
                {
                    return BadRequest();
                }
                //return new ObjectResult(item);

                return response = Ok(new { result = "Success", item });
            }
            catch (Exception erc)
            {
                return response = Ok(new { result = "Error", detalle = "detalle: " + erc.Message });
            }

        }
        #region
        [HttpGet("GetCat_SuperlineChange/{idsuperlinea}")]
        public IActionResult GetCat_SuperlineChange(int idsuperlinea)
        {
            var item = (from a in _context.Cat_Linea_Producto
                        where a.id_superlinea == idsuperlinea
                        select new
                        {
                            id = a.id,
                            descripcion = a.descripcion,
                            estatus = a.estatus,
                            idsuperlinea = a.id_superlinea
                        }).ToList();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }

        [HttpGet("obtCatalogoSuperLinea")]
        public IActionResult obtCatalogoSuperLinea()
        {
            var item = (from a in _context.cat_SuperLineas
                            //join b in _context.Cat_Linea_Producto on  a.id equals b.id_superlinea
                            //join b in _context.Cat_Categoria_Producto on a.id_categoria equals b.id
                            //join c in _context.Cat_Linea_Producto on a.id_linea equals c.id
                            //join d in _context.Cat_SubLinea_Producto on a.id_sublinea equals d.id
                            //where d.id_linea_producto != 36 && d.id_linea_producto != 38
                        select new
                        {
                            id = a.id,
                            superlinea = a.descripcion,
                            lineasociadas = _context.Cat_Linea_Producto.Where(c => c.id_superlinea == a.id).Count(),
                            activo = a.activo,
                            orden = a.orden
                        }).ToList().OrderBy(a => a.orden);

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }

        [HttpPut("actualizarCatalogoSuperLinea/{id}")]
        public IActionResult actualizarCatalogoSuperLinea(int id, [FromBody]ProductSuperLineaEdit productsuperLineaEdit)
        {
            try
            {
                var _valoressuperLinea = productsuperLineaEdit.value.Split(',');
                var _orden = Convert.ToInt32(_valoressuperLinea[0]);
                var _value = Convert.ToInt32(_valoressuperLinea[1]);
                Cat_SuperLinea _superlinea00 = new Cat_SuperLinea();

                _superlinea00 = _context.cat_SuperLineas.Where(a => a.orden == _value).FirstOrDefault();
                if (_superlinea00 != null)
                {
                    _superlinea00.orden = _orden;
                    var _updateSuperLinea00 = _context.Update(_superlinea00);
                    _superlinea00 = _context.cat_SuperLineas.Where(b => b.id == id).FirstOrDefault();
                    _superlinea00.orden = _value;
                    var _updateSuperLinea01 = _context.Update(_superlinea00);

                }
                _context.SaveChanges();
                return Ok(1);

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        [HttpGet("GetCat_canales")]
        public IActionResult GetCat_canales()
        {
            //var item = (from a in _context.Cat_Catalogo_Super_Linea
            //            select new
            //            {
            //                id = a.id
            //                //lineasAsociadas = _context.Cat_Linea_Producto.Where(d => d.id_superlinea == a.id).ToList()
            //            }).ToList();


            var item = (from a in _context.Cat_canales
                        select new
                        {
                            id = a.Id,
                            canales = a.Canal_es
                        }
                         );

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }
        [HttpPut("saveCatalogo_Super_Linea/{descripcion}/{active}/{SlId}")]
        public IActionResult saveCatalogo_Super_Linea(string descripcion, bool active, int SlId)
        {
            try
            {
                Cat_Catalogo_Super_Linea _catsuperlinea00 = new Cat_Catalogo_Super_Linea();
                Cat_SuperLinea _superlinea00 = new Cat_SuperLinea();
                //Cat_canales _canales00 = new Cat_canales();
                int maxOrden;
                if (SlId != 0)
                {
                    _superlinea00 = _context.cat_SuperLineas.Where(wr => wr.id == SlId).FirstOrDefault();
                    //maxOrden = _context.cat_SuperLineas.Where(wr => wr.id == SlId).FirstOrDefault().orden;
                    _superlinea00.descripcion = descripcion;
                    _superlinea00.activo = active;
                }
                else
                {
                    maxOrden = _context.cat_SuperLineas.Max(p => p.orden);
                    _superlinea00.orden = maxOrden + 1;
                    _superlinea00.descripcion = descripcion;
                    _superlinea00.estatus = true;
                    _superlinea00.activo = active;
                    //_superlinea00.id = SlId;

                }
               
                var item = _context.Update(_superlinea00);
                _context.SaveChanges();

                if (item == null)
                {
                    return BadRequest();
                }
                return new ObjectResult(item.Entity);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }

        }
        /// <summary>
        /// Add and update Cat_Super_Linea
        /// </summary>
        /// <param name="catalogosuperlinea"></param>
        /// <returns></returns>
        [HttpPut("UpdateCatalogo_Super_Linea")]
        public IActionResult UpdateCatalogo_Super_Linea([FromBody]SuperLineCanalModel catalogosuperlinea)
        {
            try
            {
                catalogosuperlinea.canales.Sort();
                List<int> save = new List<int>();
                List<Cat_Catalogo_Super_Linea> listCanales = _context.Cat_Catalogo_Super_Linea.Where(wr => wr.catsuperlineaid == catalogosuperlinea.idSuperLine).Include(inc => inc.catsuperlinea).ToList();
                if (listCanales.Count == 0)
                {
                    listCanales = new List<Cat_Catalogo_Super_Linea>();

                    for (int i = 1; i <= 3; i++)
                    {
                        Cat_Catalogo_Super_Linea superLineCan = new Cat_Catalogo_Super_Linea();
                        superLineCan.catsuperlineaid = catalogosuperlinea.idSuperLine;
                        //superLineCan.cat_canales. = i;
                        superLineCan.cat_canalesId = i;
                        foreach (int canal in catalogosuperlinea.canales)
                        {
                            if (canal == i)
                                superLineCan.isActive = true;
                            else
                                superLineCan.isActive = false;
                        }


                        listCanales.Add(superLineCan);
                    }

                    _context.Cat_Catalogo_Super_Linea.AddRange(listCanales);
                }
                else
                {
                    int count = 0;
                    foreach (Cat_Catalogo_Super_Linea catalog in listCanales)
                    {
                        if (catalogosuperlinea.canales.Count != 0)
                        {
                            if (catalog.cat_canalesId == catalogosuperlinea.canales[count])
                            {
                                catalog.isActive = true;
                                if (count != (catalogosuperlinea.canales.Count - 1))
                                {
                                    count++;
                                }
                            }
                            else
                            {
                                //if (count != catalogosuperlinea.canales.Count)
                                //{
                                //    count++;
                                //}
                                catalog.isActive = false;
                            }
                        }
                        else
                        {
                            catalog.isActive = false;
                        }
                        
                        
                    }


                    _context.Cat_Catalogo_Super_Linea.UpdateRange(listCanales);
                }
                _context.SaveChanges();

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

            //Cat_Catalogo_Super_Linea _catsuperlinea00 = new Cat_Catalogo_Super_Linea();
            //Cat_SuperLinea _superlinea00 = new Cat_SuperLinea();
            //Cat_canales _canales00 = new Cat_canales();
            //var valores = catalogosuperlinea.conjunto.Split(',');
            //_canales00 = _context.Cat_canales.Where(a => a.Id == Convert.ToInt32(valores[0])).FirstOrDefault();
            //_superlinea00 = _context.cat_SuperLineas.Where(a => a.id == Convert.ToInt32(valores[1])).FirstOrDefault();
            //_catsuperlinea00.cat_canales = _canales00;
            //_catsuperlinea00.catsuperlinea = _superlinea00;
            //var item = _context.Update(_catsuperlinea00);
            //_context.SaveChanges();
            //if (item == null)
            //{
            //    return BadRequest();
            //}
            //return new ObjectResult(item.Entity);
        }

        [HttpGet("GetSuperLineContenido")]
        public IActionResult GetSuperLineContenido()
        {
            var item = (from a in _context.cat_SuperLineas
                        select new
                        {
                            id = a.id,
                            superlinea = a.descripcion,
                            activo = a.activo,
                            //disponibilidadCanales = _context.Cat_Catalogo_Super_Linea.Where(c => c.catsuperlinea.id == a.id).ToList(),
                            //lineasAsociadas = _context.Cat_Linea_Producto.Where(d => d.id_superlinea == a.id).ToList()
                        }).ToList();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }
        [HttpGet("GetCat_Linea_Producto/{id}")]
        public IActionResult GetCat_Linea_Producto(int id)
        {
            var item = (from a in _context.Cat_Linea_Producto
                        select new
                        {
                            id = a.id,
                            descripcion = a.descripcion,
                            estatus = a.estatus,
                            idsuperlinea = a.id_superlinea
                            //lineasAsociadas = _context.Cat_Linea_Producto.Where(d => d.id_superlinea == a.id).ToList()
                        }).Where(a => a.idsuperlinea == id).ToList();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }
        [HttpGet("GetCat_Catalogo_SuperLinea_ID/{id}")]
        public IActionResult GetCat_Catalogo_SuperLinea_ID(int id)
        {
            var item = (from a in _context.Cat_Catalogo_Super_Linea
                        join b in _context.cat_SuperLineas on a.catsuperlinea.id equals b.id
                        //join d in _context.Cat_canales on a.cat_canales.Id equals d.Id
                        select new
                        {
                            id = a.id,
                            catsuperlineaid = b.id,
                            compatibible = a.compatible,
                            canalNombre = _context.Cat_canales.Where(c => (c.Id == a.cat_canales.Id)).FirstOrDefault(),
                            isActive = a.isActive
                        }).Where(a => a.catsuperlineaid == id && (a.isActive == true)).ToList();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }
        [HttpGet("GetSuperLineContenidoActivo/{id}")]
        public IActionResult GetSuperLineContenidoActivo(int id)
        {
            //from a in _context.Cat_Productos.Where(p => p.id == id)
            var item = (from a in _context.cat_SuperLineas.Where(p => p.id == id)
                        select new
                        {
                            id = a.id,
                            superlinea = a.descripcion,
                            activo = a.activo,
                            //disponibilidadCanales = _context.Cat_Catalogo_Super_Linea.Where(c => c.catsuperlinea.id == a.id).ToList(),
                            //lineasAsociadas = _context.Cat_Linea_Producto.Where(d => d.id_superlinea == a.id).ToList()
                        }).FirstOrDefault();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }

        [HttpGet("obtCatalogoSuperLineaDescripcion/{id}")]
        public IActionResult obtCatalogoSuperLineaDescripcion(int id)
        {
            Cat_SuperLinea _catsuperlinea = new Cat_SuperLinea();
            _catsuperlinea = _context.cat_SuperLineas.Where(b => b.id == id).FirstOrDefault();
            var item = (from a in _context.Cat_Linea_Producto
                        where (a.id_superlinea == id)
                        select new
                        {
                            id = a.id,
                            superlinea = _catsuperlinea.descripcion, //a.descripcion,
                            lineasociadas = a.descripcion,
                            activo = a.estatus
                        }).ToList();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }
        [HttpGet("GetCat_Linea_ProductoAll")]
        public IActionResult GetCat_Linea_ProductoAll()
        {
            var item = (from a in _context.Cat_Linea_Producto
                        select new
                        {
                            id = a.id,
                            descripcion = a.descripcion,
                            estatus = a.estatus,
                            idsuperlinea = a.id_superlinea
                        }).ToList();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }

        [HttpPut("SaveCatalogoLinea/")]
        public IActionResult SaveCatalogoLinea([FromBody]SuperLineCreate cat_line_producto_Em)
        {
            Cat_Linea_Producto _lineproduct00 = new Cat_Linea_Producto();
            var cat_line_producto = cat_line_producto_Em.conjunto.Split(',');
            //_lineproduct00.id = Convert.ToInt32(cat_line_producto[0]);
            _lineproduct00.descripcion = cat_line_producto[0];
            _lineproduct00.estatus = Convert.ToBoolean(cat_line_producto[1]);
            _lineproduct00.id_superlinea = Convert.ToInt32(cat_line_producto[2]);
            var item = _context.Cat_Linea_Producto.Add(_lineproduct00);
            _context.SaveChanges();
            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item.Entity);
        }
        [HttpGet("obtCatalogoLineaDescripcion/{id}")]
        public IActionResult obtCatalogoLineaDescripcion(int id)
        {
            //Cat_SuperLinea _catsuperlinea = new Cat_SuperLinea();
            //_catsuperlinea = _context.cat_SuperLineas.Where(b => b.id == id).FirstOrDefault();
            var item = (from a in _context.Cat_Linea_Producto
                        where (a.id == id)
                        select new
                        {
                            id = a.id,
                            descripcion = a.descripcion, //a.descripcion,
                            estatus = a.estatus,
                            id_superlinea = a.id_superlinea
                        }).FirstOrDefault();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="cat_line_producto_Em"></param>
        /// <returns></returns>
        [HttpPut("UpdateCatalogoLinea/")]
        public IActionResult UpdateCatalogoLinea([FromBody]SuperLineCreate cat_line_producto_Em)
        {
            Cat_Linea_Producto _lineproduct00 = new Cat_Linea_Producto();
            var cat_line_producto = cat_line_producto_Em.conjunto.Split(',');
            _lineproduct00.id = Convert.ToInt32(cat_line_producto[0]);
            _lineproduct00.descripcion = cat_line_producto[1];
            _lineproduct00.estatus = Convert.ToBoolean(cat_line_producto[2]);
            _lineproduct00.id_superlinea = Convert.ToInt32(cat_line_producto[3]);
            var item = _context.Update(_lineproduct00);
            _context.SaveChanges();
            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item.Entity);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("ProductosID/{id}")]
        public IActionResult GetProductID(int id)
        {
            //var _resultado= _context.Stock_Inicial
            var item = (from a in _context.Cat_Productos.Where(p => p.id == id)
                            //join b in _context.Cat_Categoria_Producto on a.id_categoria equals b.id
                        join c in _context.Cat_Linea_Producto on a.id_linea equals c.id
                        join d in _context.Cat_SubLinea_Producto on a.id_sublinea equals d.id
                        join e in _context.cat_SuperLineas on c.id_superlinea equals e.id
                        join f in _context.Stock_Inicial on a.stcInicial.id equals f.id
                        select new
                        {
                            id = a.id,
                            nombre = a.nombre,
                            categoria = c.descripcion,
                            a.id_linea,
                            superlinea = e.id,
                            linea = c.descripcion,
                            a.id_sublinea,
                            sublinea = d.descripcion,
                            descripcion_corta = a.descripcion_corta,
                            descripcion_larga = a.descripcion_larga,
                            ficha_tecnica = a.ficha_tecnica,
                            precio_sin_iva = a.precio_sin_iva,
                            precio_con_iva = a.precio_con_iva,
                            sku = a.sku,
                            tipo = a.tipo,
                            minimocarrito = a.minimo_Carrito == null ? false : a.minimo_Carrito,
                            numeroMinimoCarrito = a.numero_Minimi_Carrito == null ? 0 : a.numero_Minimi_Carrito,
                            manejostockcheck = a.manejos_stock_check == null ? false : a.manejos_stock_check,
                            stock_inicial = f.stock_inicial == null ? 0 : f.stock_inicial,
                            stock_actual = f.stock_actual == null ? 0 : f.stock_actual,
                            stock_desplazado = f.stock_desplazado == null ? 0 : f.stock_desplazado,
                            //stock_inicial = a.stcInicial.stock_inicial == null ? 0 : a.stcInicial.stock_inicial,
                            //stock_actual = a.stcInicial.stock_actual == null ? 0 : a.stcInicial.stock_actual,
                            //stock_desplazado = a.stcInicial.stock_desplazado == null ? 0 : a.stcInicial.stock_desplazado,
                            img_url = (from x in _context.Cat_Imagenes_Producto
                                       where x.id_producto == a.id
                                       select x)
                                         .Select(c => new Cat_Imagenes_Producto
                                         {
                                             id = c.id,
                                             id_producto = c.id_producto,
                                             url = c.url,
                                             estatus = c.estatus
                                         }).FirstOrDefault()
                        }).FirstOrDefault();

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("Delete_Catalogo_Super_Linea/{id}")]
        public IActionResult Delete_Catalogo_Super_Linea(int id)
        {
            List<Cat_Catalogo_Super_Linea> catcatalogosuperlinea = new List<Cat_Catalogo_Super_Linea>();
            Cat_SuperLinea catsuperlinea = new Cat_SuperLinea();
            try
            {
                catsuperlinea = _context.cat_SuperLineas.Where(a => a.id == id).FirstOrDefault();
                catcatalogosuperlinea = _context.Cat_Catalogo_Super_Linea
                    .Where(a => a.catsuperlinea == catsuperlinea)
                    .ToList();
                foreach (var item in catcatalogosuperlinea)
                {
                    var _resultado = _context.Remove(item);

                    if (_resultado == null)
                    {
                        return BadRequest();
                    }
                }
                _context.SaveChanges();
            }
            catch (Exception erc)
            {
                return BadRequest();
            }
            return new ObjectResult(catcatalogosuperlinea);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="cat_SuperLineas"></param>
        /// <returns></returns>
        [HttpPut("UpdateCat_SuperLineas/")]
        public IActionResult UpdateCat_SuperLineas([FromBody]SuperLineCreate cat_SuperLineas)
        {
            var _contenido = cat_SuperLineas.conjunto.Split(',');
            int _idSuperLinea = Convert.ToInt32(_contenido[0]);
            bool _activo = Convert.ToBoolean(_contenido[1]);
            Cat_SuperLinea _superlinea00 = new Cat_SuperLinea();
            _superlinea00 = _context.cat_SuperLineas.Where(a => a.id == _idSuperLinea).FirstOrDefault();
            _superlinea00.activo = _activo;
            var item = _context.Update(_superlinea00);
            _context.SaveChanges();
            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item.Entity);
        }

        [HttpPut("ProductoStockVerificaExistenciaUpdate/{id}")]
        public IActionResult ProductoStockVerificaExistenciaUpdate(int id)
        {
            IActionResult response = Unauthorized();
            Stock_Inicial _stockinicial = new Stock_Inicial();
            try
            {
                _stockinicial = _context.Stock_Inicial.Where(r => r.id == id).FirstOrDefault();
                //var _tempActual = _stockinicial.stock_temp_actual + 1;
                //_stockinicial.stock_temp_actual = _tempActual;
                var item = _context.Stock_Inicial.Update(_stockinicial);
                _context.SaveChanges();
                ////var _resultado= _context.Stock_Inicial
                //var item = (from a in _context.Cat_Productos.Where(p => p.id == id)
                //                //join b in _context.Cat_Categoria_Producto on a.id_categoria equals b.id
                //            join c in _context.Cat_Linea_Producto on a.id_linea equals c.id
                //            join d in _context.Cat_SubLinea_Producto on a.id_sublinea equals d.id
                //            join e in _context.cat_SuperLineas on c.id_superlinea equals e.id
                //            join f in _context.Stock_Inicial on a.stcInicial.id equals f.id
                //            select new
                //            {
                //                stcInicialid = a.stcInicialid,
                //                stock_inicial = f.stock_inicial == null ? 0 : f.stock_inicial,
                //                stock_actual = f.stock_actual == null ? 0 : f.stock_actual,
                //                stock_desplazado = f.stock_desplazado == null ? 0 : f.stock_desplazado,
                //                stock_temp_actual = f.stock_temp_actual == null ? 0 : f.stock_temp_actual

                //            }).FirstOrDefault();

                if (item == null)
                {
                    return BadRequest();
                }
                //return new ObjectResult(item);

                return response = Ok(new { result = "Success" });
            }
            catch (Exception erc)
            {
                return response = Ok(new { result = "Error", detalle = "detalle: " + erc.Message });
            }

        }

        [HttpPut]
        [Route("UpdateProd")]
        public IActionResult UpdateProduct([FromBody]ProductsUpdateDto productsUpdateDto)
        {
            try
            {
                //if (!_repo.Exists(id))
                //    return NotFound($"Product with Id { id } Not Found");

                if (!_repoProductCategories.Exists(productsUpdateDto.id_categoria))
                    return NotFound($"Product category with Id { productsUpdateDto.id_categoria } Not Found");

                if (!_repoProductLines.Exists(productsUpdateDto.id_linea))
                    return NotFound($"Product line with Id { productsUpdateDto.id_linea } Not Found");

                if (!_repoProductSubLines.Exists(productsUpdateDto.id_sublinea))
                    return NotFound($"Product sub line with Id { productsUpdateDto.id_sublinea } Not Found");


                //productsUpdateDto.cat_imagenes_producto
                //var result = _repo.Get(id);
                Cat_Productos product = _mapper.Map<Cat_Productos>(productsUpdateDto);
                product.id = productsUpdateDto.id;
                product.manejos_stock_check = productsUpdateDto.manejostockcheck;
                var result = _context.Update(product);
                //string res = GuardarRelacionados(productsUpdateDto.relacionados, id);
                List<productos_relacionados> nuevos = productsUpdateDto.relacionados.Where(r => r.id == 0).ToList();
                List<productos_relacionados> act = productsUpdateDto.relacionados.Where(r => r.id > 0).ToList();
                List<productos_relacionados> exis = _context.productos_relacionados.Where(p => p.id_producto == productsUpdateDto.id || p.id_producto_2 == productsUpdateDto.id).ToList();
                List<Cat_Imagenes_Producto> imgs = _context.Cat_Imagenes_Producto.Where(i => i.id_producto == productsUpdateDto.id).ToList();
                foreach (ProductImagesDto item in productsUpdateDto.cat_imagenes_producto)
                {
                    if (!imgs.Exists(db => db.url == item.url))
                    {
                        _context.Cat_Imagenes_Producto.Add(new Cat_Imagenes_Producto { estatus = true, id_producto = productsUpdateDto.id, url = item.url });
                    }
                }

                foreach (productos_relacionados item in exis)
                {
                    if (!act.Exists(c => c.id == item.id))
                    {
                        _context.productos_relacionados.Remove(item);
                    }
                }

                foreach (productos_relacionados item in nuevos)
                {
                    _context.productos_relacionados.Add(item);
                }
                _context.SaveChanges();
                //result.id_categoria = _repoProductCategories.Get(productLinesUpdateDto.id_categoria);
                //resul = productLinesUpdateDto.descripcion;
                //result.estatus = productLinesUpdateDto.estatus;
                //_repo.Update(result, id);

                return Ok();

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetLineData")]
        public IActionResult GetLine()
        {

            List<Cat_SuperLinea> _catsuperlinea = new List<Cat_SuperLinea>();
            _catsuperlinea = _context.cat_SuperLineas.ToList();
            var item = (from a in _context.Cat_Linea_Producto
                       
                        select new
                        {
                            id = a.id,
                            superlinea = _catsuperlinea.Find(find => find.id == a.id_superlinea).descripcion, //a.descripcion,
                            lineasociadas = a.descripcion,
                            activo = a.estatus,
                            idSuperLine = _catsuperlinea.Find(find => find.id == a.id_superlinea).id
                        }).ToList();
         

            if (item == null)
            {
                return BadRequest();
            }
            return new ObjectResult(item);
        }
        #endregion
    }



}
