﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.ViewModels
{
    public class ProductsRelatedDto
    {
        public int id { get; set; }
        public int id_producto { get; set; }
        public int id_producto_2 { get; set; }
    }
}
