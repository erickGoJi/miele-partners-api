﻿using Newtonsoft.Json;

namespace WebApplication.ViewModels
{
    public class ProductImagesDto
    {
        public int id { get; set; }
        public string url { get; set; }
        public bool estatus { get; set; }
    }
}
