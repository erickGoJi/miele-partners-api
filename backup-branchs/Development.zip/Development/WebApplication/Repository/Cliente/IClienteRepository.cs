﻿using WebApplication.Models;
using WebApplication.Repositoriy.Generic;

namespace WebApplication.Repository
{
    public interface IClienteRepository : IGenericRepository<Clientes>
    {

    }
}
