﻿namespace WebApplication.Models.Dashboard
{
    public class Porcentaje
    {
        public decimal? Resultado { get; set; }

        public Porcentaje()
        {
            Resultado = null;
        }
    }
}
