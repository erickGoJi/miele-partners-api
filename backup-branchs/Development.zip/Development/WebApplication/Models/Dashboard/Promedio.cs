﻿namespace WebApplication.Models.Dashboard
{
    public class Promedio
    {
        public int? Resultado { get; set; }

        public Promedio()
        {
            Resultado = null;
        }
    }
}
