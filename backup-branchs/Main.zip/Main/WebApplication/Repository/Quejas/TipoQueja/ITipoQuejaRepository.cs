﻿using WebApplication.Models;
using WebApplication.Repositoriy.Generic;

namespace WebApplication.Repository
{
    public interface ITipoQuejaRepository : IGenericRepository<TipoQueja>
    {

    }
}
