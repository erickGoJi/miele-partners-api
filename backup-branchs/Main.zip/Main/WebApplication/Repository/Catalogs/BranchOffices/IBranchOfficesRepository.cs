﻿using WebApplication.Models;
using WebApplication.Repositoriy.Generic;

namespace WebApplication.Repository
{

    public interface IBranchOfficesRepository: IGenericRepository<Cat_Sucursales>
    {
    }
}
