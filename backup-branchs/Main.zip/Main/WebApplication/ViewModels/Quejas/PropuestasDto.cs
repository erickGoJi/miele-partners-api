﻿using Newtonsoft.Json;

namespace WebApplication.ViewModels
{
    public class PropuestasDto
    {
        public string Solucion { get; set; }
        public string DetalleCierre { get; set; }
    }
}
