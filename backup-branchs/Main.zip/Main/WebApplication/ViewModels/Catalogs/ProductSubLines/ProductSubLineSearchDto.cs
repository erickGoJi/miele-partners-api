﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.ViewModels
{
    public class ProductSubLineSearchDto
    {
        public string text { get; set; }
        public int id_linea_producto { get; set; }
        public bool estatus { get; set; }
    }
}
