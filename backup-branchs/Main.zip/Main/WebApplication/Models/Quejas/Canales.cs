﻿namespace WebApplication.Models
{
    public class Canales
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
